-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.67-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema online_horoscope_system
--

CREATE DATABASE IF NOT EXISTS online_horoscope_system;
USE online_horoscope_system;

--
-- Definition of table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(10) unsigned NOT NULL auto_increment,
  `admin_name` varchar(50) NOT NULL,
  `admin_DOB` datetime NOT NULL,
  `admin_address` varchar(300) NOT NULL,
  `admin_email` varchar(30) NOT NULL,
  `admin_ph` varchar(20) NOT NULL,
  `admin_username` varchar(15) NOT NULL,
  `admin_password` varchar(15) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`admin_id`,`admin_name`,`admin_DOB`,`admin_address`,`admin_email`,`admin_ph`,`admin_username`,`admin_password`) VALUES 
 (1,'Phyo Phyo','1996-03-18 00:00:00','Yangon,Myanmar','bakafool12@gmail.com','+(959)73236937','phyo phyo','phyophyo');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


--
-- Definition of table `astology`
--

DROP TABLE IF EXISTS `astology`;
CREATE TABLE `astology` (
  `astology_id` int(10) unsigned NOT NULL auto_increment,
  `horoscope_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `astology_description` text NOT NULL,
  `price` float NOT NULL,
  `daily_horoscope_status` tinyint(1) NOT NULL,
  `monthly_horoscope_status` tinyint(1) NOT NULL,
  `annually_horoscope_status` tinyint(1) NOT NULL,
  `update_adminID` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`astology_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `astology`
--

/*!40000 ALTER TABLE `astology` DISABLE KEYS */;
INSERT INTO `astology` (`astology_id`,`horoscope_id`,`tag_id`,`astology_description`,`price`,`daily_horoscope_status`,`monthly_horoscope_status`,`annually_horoscope_status`,`update_adminID`) VALUES 
 (1,1,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (2,2,1,'<u>As your love </u> Your are good future but you should stay as a single.',110,1,0,0,1),
 (3,3,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (4,4,1,'<u>As your love </u> Your are good future but you should stay as a single.',90,1,0,0,1),
 (5,5,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (6,6,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (7,7,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (8,8,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (9,9,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (10,10,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (11,11,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (12,12,1,'<u>As your love </u> Your are good future but you should stay as a single.',100,1,0,0,1),
 (13,1,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (14,2,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (15,3,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (16,4,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (17,5,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (18,6,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (19,7,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (20,8,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (21,9,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (22,10,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (23,11,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (24,12,2,'<u>As your Education </u> Your are good future and try more.',100,1,0,0,1),
 (25,1,1,'<u>As your love </u> You are bad future and don\'t give and accept the chance to everyone',200,0,1,0,1),
 (26,2,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (27,3,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (28,4,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (29,5,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (30,6,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (31,7,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (32,8,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (33,9,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (34,10,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (35,11,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (36,12,1,'<u>As your love </u> Your are good future but you should stay as a single.',200,0,1,0,1),
 (37,1,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (38,2,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (39,3,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (40,4,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (41,5,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (42,6,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (43,7,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (44,8,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (45,9,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (46,10,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (47,11,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (48,12,2,'<u>As your Education </u> Your are bedfuture and try hard.',200,0,1,0,1),
 (49,1,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (50,2,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (51,3,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (52,4,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (53,5,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (54,6,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (55,7,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (56,8,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (57,9,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (58,10,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (59,11,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (60,12,1,'<u>As your love </u> Your are good future but you should stay as a single.',300,0,0,1,1),
 (61,1,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (62,2,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (63,3,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (64,4,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (65,5,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (66,6,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (67,7,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (68,8,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (69,9,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (70,10,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (71,11,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (72,12,2,'<u>As your Education </u> Your are bedfuture and try hard.',300,0,0,1,1),
 (73,7,2,'newnew',999,1,0,0,0),
 (75,1,1,'newnewiiii',888,1,0,0,0),
 (76,1,1,'<u>As your love </u> Your are good future but you ',110,1,0,0,0),
 (79,2,2,'abc',444,1,0,0,0),
 (80,1,1,'jhjj',7777,1,0,0,0),
 (81,0,0,'',0,0,0,1,0),
 (82,0,0,'',0,0,0,1,0);
/*!40000 ALTER TABLE `astology` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customer_id` int(10) unsigned NOT NULL auto_increment,
  `customer_name` varchar(50) NOT NULL,
  `customer_DOB` date default NULL,
  `customer_username` varchar(15) NOT NULL,
  `customer_password` varchar(15) NOT NULL,
  `RegisterDate` date NOT NULL,
  `customer_gender` char(1) NOT NULL,
  `customer_country` varchar(20) NOT NULL,
  `customer_NRC` varchar(25) NOT NULL,
  `customer_address` varchar(300) NOT NULL,
  `Balance` float NOT NULL,
  `Email` varchar(45) default NULL,
  PRIMARY KEY  (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`customer_id`,`customer_name`,`customer_DOB`,`customer_username`,`customer_password`,`RegisterDate`,`customer_gender`,`customer_country`,`customer_NRC`,`customer_address`,`Balance`,`Email`) VALUES 
 (1,'jenny','0000-00-00','Jenny','jenny','2014-01-20','','coun','nrc','yangon',0,'jenny@gmail.com'),
 (2,'Wan Phay','1992-02-10','wan wan','wanwan','2011-01-01','M','Tine Pay','A22022','Time Pay.China',700,'wan@gmail.com'),
 (3,'Cathy Smith','1982-08-12','cathy Smith','cathysmith','2013-08-09','F','Australia','AA20004','Australia,England',2800,'cathy@gmail.com'),
 (4,'Paing Wai Sin','1996-01-20','paing Wai','paingwai','2011-05-08','M','Myanmar','12/(Naing)121212','Shan,Myanmar',200,'paing@gmail.com'),
 (5,'Myat Phyo','1993-11-18','myat myat','myatmyat','2012-06-28','','Myanmar','12(Naming)1831996','Myanmar',778177,'myat@gmail.com'),
 (6,'Thu Thu','1994-03-01','thuthu','thuthu','2011-05-05','','Myanmar','12/(Naing)11111','Myanmar',9100,'thu@gmail.com'),
 (7,'ma','1990-01-01','a','123','2014-01-01','1','mm','asjdo','asdf',0,'ma@gmail.com'),
 (8,'$customer_name','0000-00-00','$customer_usern','$customer_passw','0000-00-00','$','$customer_country','$customer_NRC','$customer_address',0,NULL),
 (9,'mm','0000-00-00','','','0000-00-00','7','789','hui','yui',-4718,NULL),
 (11,'kko','0000-00-00','ko','o','0000-00-00','','Amercia','jo','ko',0,'ijo'),
 (12,'ko','0000-00-00','k','ko','0000-00-00','','Amercia','joi','jio',0,'jo'),
 (13,'dsko','0000-00-00','sf','ko','2014-03-12','','Amercia','jo','joi',0,'oj'),
 (14,'sfo','0000-00-00','sdf','ki','2014-03-12','','Amercia','hi','hi',0,'jo'),
 (15,'lo','2014-03-02','hki','oi','2014-03-12','','Amercia','hi','hii',0,'jo'),
 (16,'koko','2014-03-02','koko','koko','2014-03-12','','Amercia','koko','abc',0,'koko@gmail.com'),
 (17,'','0000-00-00','','','2014-03-14','','Amercia','','',-4718,''),
 (18,'jj','0000-00-00','','','2014-03-14','','Amercia','','',-4718,''),
 (19,'jj','0000-00-00','','','2014-03-14','','Amercia','','',-4718,''),
 (20,'jj','0000-00-00','','','2014-03-14','','Amercia','','',-4718,''),
 (21,'','0000-00-00','','','2014-03-14','','Amercia','','',-4718,''),
 (22,'Ko Ko','0000-00-00','','','2014-04-01','','Amercia','','',-4718,'koko@gmail.com'),
 (23,'Ko Ko','2014-04-01','Ko Ko','koko','2014-04-01','','British','AD44800','Wstern',0,'koko@gmail.com'),
 (24,'july','2014-04-01','july','july','2014-04-07','','Canada','AD11111','Candananar',0,'july@gmail.com'),
 (25,'awrqwe','2014-04-16','adfe','afefwe','2014-04-07','','Amercia','et4t4','hdfahf',0,'aswg'),
 (27,'Yadana','2014-03-18','Yadana','Yadana','2014-04-21','','Myanmar','AD99090','Myanmar',0,'Yadana@gmail.com'),
 (28,'lamin','1996-03-18','lamin','lamin','2014-04-29','','Canada','AD1831996','Yangon,Burma',0,'lamin@gmail.com'),
 (29,'test','1996-04-01','test','test','2014-04-30','','British','AD11111','Yangon,Burma',1000,'test@gmail.com');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `customer_astology`
--

DROP TABLE IF EXISTS `customer_astology`;
CREATE TABLE `customer_astology` (
  `customer_id` int(10) unsigned NOT NULL,
  `astology_id` int(10) unsigned NOT NULL,
  `price` float NOT NULL,
  `view_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_astology`
--

/*!40000 ALTER TABLE `customer_astology` DISABLE KEYS */;
INSERT INTO `customer_astology` (`customer_id`,`astology_id`,`price`,`view_date`) VALUES 
 (1,3,100,'2014-04-28 00:00:00'),
 (1,2,110,'2014-04-28 00:00:00'),
 (1,2,110,'2014-04-28 00:00:00'),
 (1,3,100,'2014-04-28 00:00:00'),
 (1,3,100,'2014-04-29 00:00:00'),
 (1,2,110,'2014-04-29 00:00:00'),
 (1,2,110,'2014-04-29 00:00:00'),
 (1,4,90,'2014-04-29 00:00:00'),
 (1,4,90,'2014-04-29 00:00:00'),
 (1,4,90,'2014-04-29 00:00:00'),
 (1,4,90,'2014-04-29 00:00:00'),
 (1,4,90,'2014-04-29 00:00:00'),
 (1,2,110,'2014-04-29 00:00:00'),
 (1,2,110,'2014-04-29 00:00:00'),
 (1,2,110,'2014-04-29 00:00:00'),
 (1,2,110,'2014-04-29 00:00:00'),
 (1,4,90,'2014-04-29 00:00:00'),
 (1,2,110,'2014-04-29 00:00:00'),
 (6,2,110,'2014-04-29 00:00:00'),
 (6,4,90,'2014-04-29 00:00:00'),
 (6,4,90,'2014-04-29 00:00:00'),
 (1,2,110,'2014-04-29 00:00:00'),
 (6,1,100,'2014-04-29 00:00:00'),
 (6,1,100,'2014-04-30 00:00:00'),
 (1,63,300,'2014-04-30 00:00:00'),
 (1,63,300,'2014-04-30 00:00:00'),
 (1,63,300,'2014-04-30 00:00:00'),
 (6,61,300,'2014-05-02 00:00:00'),
 (1,61,300,'2014-05-02 00:00:00'),
 (6,62,300,'2014-05-02 00:00:00');
/*!40000 ALTER TABLE `customer_astology` ENABLE KEYS */;


--
-- Definition of table `customer_credit`
--

DROP TABLE IF EXISTS `customer_credit`;
CREATE TABLE `customer_credit` (
  `customer_id` int(10) unsigned NOT NULL,
  `prepaid_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_credit`
--

/*!40000 ALTER TABLE `customer_credit` DISABLE KEYS */;
INSERT INTO `customer_credit` (`customer_id`,`prepaid_id`) VALUES 
 (1,1),
 (2,2),
 (3,3),
 (4,4),
 (5,5),
 (1,444444),
 (0,0),
 (0,0),
 (0,0),
 (3,222222),
 (1,666666),
 (1,5555555),
 (6,9999),
 (6,333333),
 (6,111),
 (5,7777777),
 (29,99999);
/*!40000 ALTER TABLE `customer_credit` ENABLE KEYS */;


--
-- Definition of table `horoscope`
--

DROP TABLE IF EXISTS `horoscope`;
CREATE TABLE `horoscope` (
  `horoscope_id` int(10) unsigned NOT NULL auto_increment,
  `horoscope_description` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `image_ID` varchar(45) default NULL,
  PRIMARY KEY  (`horoscope_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `horoscope`
--

/*!40000 ALTER TABLE `horoscope` DISABLE KEYS */;
INSERT INTO `horoscope` (`horoscope_id`,`horoscope_description`,`start_date`,`end_date`,`image_ID`) VALUES 
 (1,'Aries','2014-03-21','2014-04-19','Ariess.jpg'),
 (2,'Taurus','2014-04-20','2014-05-20','taurus.jpg'),
 (3,'Gemini','2014-05-21','2014-06-21','gemini.jpg'),
 (4,'Cancer','2014-06-22','2014-07-22','cancer.jpg'),
 (5,'Leo','2014-07-23','2014-08-21','LEO.jpg'),
 (6,'Virgo','2014-08-22','2014-09-22','virgo.jpg'),
 (7,'Libra','2014-09-23','2014-10-23','libra.jpg'),
 (8,'Scorpio','2014-10-24','2014-11-21','scoropio.jpg'),
 (9,'Sagittarius','2014-11-22','2014-12-21','sag.jpg'),
 (10,'Capricorn','2014-12-22','2014-01-19','Capricorn.jpg'),
 (11,'Aquarius','2014-01-20','2014-02-19','aquarius.jpg'),
 (12,'Pisces','2014-02-19','2014-03-20','Pisces.jpg');
/*!40000 ALTER TABLE `horoscope` ENABLE KEYS */;


--
-- Definition of table `prepaid_card`
--

DROP TABLE IF EXISTS `prepaid_card`;
CREATE TABLE `prepaid_card` (
  `prepaidcard_id` int(10) unsigned NOT NULL auto_increment,
  `prepaidcard_amount` float NOT NULL,
  `prepaidcard_currency` varchar(45) NOT NULL,
  `prepaidcard_expired_date` datetime NOT NULL,
  `prepaidcard_status` tinyint(1) NOT NULL,
  PRIMARY KEY  (`prepaidcard_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7777778 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prepaid_card`
--

/*!40000 ALTER TABLE `prepaid_card` DISABLE KEYS */;
INSERT INTO `prepaid_card` (`prepaidcard_id`,`prepaidcard_amount`,`prepaidcard_currency`,`prepaidcard_expired_date`,`prepaidcard_status`) VALUES 
 (111,200,'ASD','2016-03-03 00:00:00',0),
 (890,1500,'USD','2016-01-01 00:00:00',1),
 (1234,1000,'USD','2016-01-01 00:00:00',1),
 (4567,500,'USD','2016-01-01 00:00:00',1),
 (9999,1000,'USD','2016-01-01 00:00:00',0),
 (99999,1000,'USD','2016-01-01 00:00:00',0),
 (111111,500,'122','2016-12-31 00:00:00',0),
 (222222,500,'0','0000-00-00 00:00:00',0),
 (333333,1000,'122','2016-12-31 00:00:00',0),
 (444444,500,'122','2016-12-31 00:00:00',0),
 (666666,100,'1','2016-01-01 00:00:00',0),
 (666667,77,'0','0000-00-00 00:00:00',0),
 (4444445,5005,'125','0000-00-00 00:00:00',0),
 (7777777,777777,'USD','2016-01-01 00:00:00',0);
/*!40000 ALTER TABLE `prepaid_card` ENABLE KEYS */;


--
-- Definition of table `tag`
--

DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `tag_id` int(10) unsigned NOT NULL auto_increment,
  `tag_description` varchar(50) NOT NULL,
  PRIMARY KEY  (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tag`
--

/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` (`tag_id`,`tag_description`) VALUES 
 (1,'Love'),
 (2,'Education');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;


--
-- Definition of procedure `chk_balance`
--

DROP PROCEDURE IF EXISTS `chk_balance`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `chk_balance`(
in Acid integer
)
BEGIN

select  balance from customer where balance >(select  max(price) from astology) and customer_name=Acid;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `del_admin`
--

DROP PROCEDURE IF EXISTS `del_admin`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_admin`(
Aadmin_id int
)
BEGIN
delete from admin
where admin_id = Aadmin_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `del_astology`
--

DROP PROCEDURE IF EXISTS `del_astology`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_astology`(
Aastology_id int
)
BEGIN
delete from astology
where astology_id = Aastology_id;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `del_customer`
--

DROP PROCEDURE IF EXISTS `del_customer`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_customer`(
Acustomer_id int
)
BEGIN
delete from customer
where customer_id = Acustomer_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `del_customer_astology`
--

DROP PROCEDURE IF EXISTS `del_customer_astology`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_customer_astology`(
Acustomer_id int
)
BEGIN
delete from customer_astology
where customer_id = Acustomer_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `del_customer_credit`
--

DROP PROCEDURE IF EXISTS `del_customer_credit`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_customer_credit`(
Acustomer_id  int
)
BEGIN
delete from customer_credit
where customer_id = Acustomer_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `del_horoscope`
--

DROP PROCEDURE IF EXISTS `del_horoscope`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_horoscope`(
Ahoroscope_id int
)
BEGIN
delete from horoscope
where horoscope_id = Ahoroscope_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `del_prepaid_card`
--

DROP PROCEDURE IF EXISTS `del_prepaid_card`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_prepaid_card`(
Aprepaidcard_id int
)
BEGIN
delete from prepaid_card
where prepaidcard_id = Aprepaidcard_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `del_tag`
--

DROP PROCEDURE IF EXISTS `del_tag`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `del_tag`(
Atag_id int
)
BEGIN
delete from tag
where tag_id = Atag_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Ins_admin`
--

DROP PROCEDURE IF EXISTS `Ins_admin`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Ins_admin`(
admin_id int,
admin_name varchar(50),
admin_DOB DateTime,
admin_address varchar(300),
admin_email varchar(30),
admin_ph varchar(20),
admin_username varchar(15),
admin_password varchar(15)
)
BEGIN
INSERT
INTO admin
VALUES (admin_id,admin_name,admin_DOB,admin_address,admin_email,admin_ph,admin_username,admin_password);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Ins_astology`
--

DROP PROCEDURE IF EXISTS `Ins_astology`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Ins_astology`(
IN horor_id Integer,
IN tag_id Integer,
IN astology_description varchar(50),
IN price float,
IN daily_horoscope boolean,
IN monthly_horoscope boolean,
IN annually_hroscope boolean,
IN update_adminID integer
)
BEGIN
Insert
Into astology
values ('',horor_id,tag_id,astology_description,price,daily_horoscope,monthly_horoscope,annually_hroscope,update_adminID);

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Ins_customer`
--

DROP PROCEDURE IF EXISTS `Ins_customer`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Ins_customer`(

IN customer_name varchar(50),
IN customer_DOB Datetime,
IN customer_username varchar(15),
IN customer_password varchar(15),
IN RegisterDate Datetime,
IN customer_gender CHAR(1),
IN customer_country varchar(20),
IN customer_NRC varchar(25),
IN customer_address varchar(300),
IN AvaliableBalance Float,
In Email Varchar(45)
)
BEGIN
INSERT
INTO customer
VALUES ('',customer_name,customer_DOB,customer_username,customer_password,RegisterDate,customer_gender,customer_country,customer_NRC,customer_address,AvaliableBalance,Email);

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Ins_customer_credit`
--

DROP PROCEDURE IF EXISTS `Ins_customer_credit`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Ins_customer_credit`(
customer_id int,
prepaid_id int,
usercredit float
)
BEGIN
Insert
Into usercredit
VALUES(customer_id,prepaid_id,usercredit);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Ins_horoscope`
--

DROP PROCEDURE IF EXISTS `Ins_horoscope`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Ins_horoscope`(
IN horoscope_description varchar(50),
IN imageid varchar (45)

)
BEGIN
Insert
into horoscope
values ('',horoscope_description,'2014/12/12','2014/12/12',Image_ID);

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `ins_prepaid`
--

DROP PROCEDURE IF EXISTS `ins_prepaid`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ins_prepaid`(
 cid int(10),
 preid    int(10)

)
BEGIN
  Insert into customer_credit
   values(cid,preid);
   update  customer
   set     Balance = balance + (Select prepaidcard_amount from prepaid_card where prepaidcard_id = preid)
   where   customer_id = cid;
update  prepaid_card
set  prepaidcard_status=0
where  prepaidcard_id=preid;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Ins_prepaid_card`
--

DROP PROCEDURE IF EXISTS `Ins_prepaid_card`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Ins_prepaid_card`(
In prepaidcard_id  integer,
In prepaidcard_amount float,
In prepaidcard_currency varchar(45),
In prepaidcard_expired_date datetime,
In prepaidcard_status boolean
)
BEGIN
Insert
into prepaid_card
values (prepaidcard_id,prepaidcard_amount,prepaidcard_currency,prepaidcard_expired_date,prepaidcard_status);

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Ins_tag`
--

DROP PROCEDURE IF EXISTS `Ins_tag`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Ins_tag`(
IN tag_description varchar(50)
)
BEGIN
Insert
into tag
values ('',tag_description);

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Rpt_asking_frequency`
--

DROP PROCEDURE IF EXISTS `Rpt_asking_frequency`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Rpt_asking_frequency`(
 startdate Date
,
 enddate Date
)
BEGIN
select c.customer_id,c.customer_name,c.customer_gender,h.horoscope_description, count(CA.view_date) as 'Time_Asking',Sum(CA.Price) as 'Total_Charges'
from customer c,customer_astology CA,Astology a,horoscope h
where  c.customer_id = CA.customer_id
And    a.astology_id = CA.astology_id
And    h.horoscope_id = a.horoscope_id
And    CA.view_date between startdate and enddate

Group By c.customer_id,h.horoscope_description;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Rpt_hotelbookinglist`
--

DROP PROCEDURE IF EXISTS `Rpt_hotelbookinglist`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Rpt_hotelbookinglist`(
in fromdate date,
in todate date
)
BEGIN
select customer.Customer_Name,
        booking.`Date`,
        room.Room_Type,
        booking.Number_of_room_booked

from customer,booking,room,booking_detail
where   customer.Customer_ID=booking.Customer_ID
and booking.Booking_ID=booking_detail.Booing_ID
and room.Room_ID=booking_detail.Room_ID
and `Date` between   fromdate and todate;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Rpt_member`
--

DROP PROCEDURE IF EXISTS `Rpt_member`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Rpt_member`(
startdate date,
enddate date
)
BEGIN
select a.customer_id,a.customer_name,a.RegisterDate, Count(a.customer_nrc) as 'Total_Member'
From customer a
Where a.RegisterDate between  startdate and enddate
group
by  a.customer_id,
a.customer_name,
a.RegisterDate
order
by  a.RegisterDate;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Rpt_timeasking`
--

DROP PROCEDURE IF EXISTS `Rpt_timeasking`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Rpt_timeasking`(
`year`  int,
`month` varchar(10)
)
BEGIN
select h.horoscope_description,t.tag_description, count(CA.view_date) as 'Time_asking'
from customer_astology CA
     ,horoscope h
     ,tag t
     ,astology a
Where CA.ASTOLOGY_ID = a.ASTOLOGY_ID
AND  A.HOROSCOPE_ID = H.HOROSCOPE_ID
AND  A.TAG_ID = T.TAG_ID
AND   month(ca.view_date) = MONTH
and   year(ca.view_date) = YEAR
group by h.horoscope_description,t.tag_description
order by 'Time_asking';

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `search_astology`
--

DROP PROCEDURE IF EXISTS `search_astology`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `search_astology`(
IN  DOB date,
IN  ATag_id integer,
IN  Adstats boolean,
IN  Amstats boolean,
IN  Aystats boolean,
in Acid varchar(45)
)
BEGIN


insert into customer_astology
select  c.customer_id
        ,a.astology_id
        ,a.price
        ,curdate() as 'view_date'
from    astology a
        ,customer c
where   c.customer_username = Acid
AND     a.tag_id = ATag_id
AND     a.daily_horoscope_status = Adstats
AND     a.monthly_horoscope_status = Amstats
AND     a.annually_horoscope_status = Aystats
and     a.astology_id =
                     (
                          select max(astology_id)
                          from astology
                          where horoscope_id =  (
                                        select horoscope_id
                                        from  horoscope ho
                                        where (ho.start_date <= CONCAT('2014-',month(DOB),'-',day(DOB)) AND ho.end_date >= CONCAT('2014-',month(DOB),'-',day(DOB)))
                                        )
                     );


SELECT  distinct  a.astology_description
        ,h.image_id
FROM    horoscope h
        ,tag t
        ,astology a
WHERE   t.tag_id = a.tag_id
AND     a.horoscope_id =  (
                          select horoscope_id
                          from  horoscope ho
                          where (ho.start_date <= CONCAT('2014-',month(DOB),'-',day(DOB)) AND ho.end_date >= CONCAT('2014-',month(DOB),'-',day(DOB)))
                          )
AND     a.astology_id = (select max(astology_id)
                          from astology
                          where horoscope_id =  (
                                        select horoscope_id
                                        from  horoscope ho
                                        where (ho.start_date <= CONCAT('2014-',month(DOB),'-',day(DOB)) AND ho.end_date >= CONCAT('2014-',month(DOB),'-',day(DOB)))
                                        )
                          and   tag_id = ATag_id
                          and   daily_horoscope_status = Adstats
                          and   monthly_horoscope_status = Amstats
                          AND   annually_horoscope_status = Aystats
                          )
AND      H.horoscope_id =  (
                          select horoscope_id
                          from  horoscope ho
                          where (ho.start_date <= CONCAT('2014-',month(DOB),'-',day(DOB)) AND ho.end_date >= CONCAT('2014-',month(DOB),'-',day(DOB)))
                          )
AND     a.tag_id = ATag_id
AND     a.daily_horoscope_status = Adstats
AND     a.monthly_horoscope_status = Amstats
AND     a.annually_horoscope_status = Aystats;


update  customer
set     balance = balance - (Select a.price
                            from  astology a
                            where a.horoscope_id = (
                                                  select horoscope_id from horoscope h
                                                   where CONVERT(CONCAT('2014-',month(DOB),'-',day(DOB)), DATE) between h.start_date and h.end_date
                                                    )
                            and  a.tag_id = Atag_id
                            and  a.daily_horoscope_status = Adstats
                            and  a.monthly_horoscope_status = Amstats
                            and  a.annually_horoscope_status = Aystats
                            )
where   customer_username = Acid;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Upd_astology`
--

DROP PROCEDURE IF EXISTS `Upd_astology`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Upd_astology`(
IN Aastology Integer,
IN Ahoroscope_id Integer,
IN Atag_id Integer,
IN Aastology_description varchar(50),
IN Aprice float,
IN Adaily_horoscope boolean,
IN Amonthly_horoscope boolean,
IN Aannually_horoscope boolean,
In Aupdate_adminID int
)
BEGIN
Update astology
Set horoscope_id = Ahoroscope_id,
    tag_id=Atag_id,
    astology_description=Aastology_description,
    price=Aprice,
    daily_horoscope_status=Adaily_horoscope,
    monthly_horoscope_status=Amonthly_horoscope,
    annually_horoscope_status=Aannually_horoscope,
    update_adminID=  Aupdate_adminID
where astology_id = Aastology;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Upd_balance`
--

DROP PROCEDURE IF EXISTS `Upd_balance`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Upd_balance`(
IN Acid integer,
IN Aaid integer
)
BEGIN

update  customer
set     balance = balance - (Select price from astology where astology_id = Aaid)
where   customer_id = Acid;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Upd_customer`
--

DROP PROCEDURE IF EXISTS `Upd_customer`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Upd_customer`(
IN Acustomer_id integer,
IN Acustomer_name varchar(50),
IN Acustomer_DOB Datetime,
IN Acustomer_username varchar(15),
IN Acustomer_password varchar(15),
IN Acustomer_gender CHAR(1),
IN Acustomer_country varchar(20),
IN Acustomer_NRC varchar(25),
IN Acustomer_address varchar(300),
In Acustomer_email varchar(45)
)
BEGIN
update customer
set
 customer_name= Acustomer_name,
 customer_DOB=Acustomer_DOB,
 customer_username=Acustomer_username,
 customer_password=Acustomer_password,
 customer_gender=Acustomer_gender,
 customer_country=Acustomer_country,
 customer_NRC=Acustomer_NRC,
 customer_address=Acustomer_address,
 Email=Acustomer_email
where customer_id =Acustomer_id;


END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Upd_horoscope`
--

DROP PROCEDURE IF EXISTS `Upd_horoscope`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Upd_horoscope`(
Ahoroscope_id integer,
Ahoroscope_description varchar(50)
)
BEGIN
Update horoscope
set horoscope_description = Ahoroscope_description
where horoscope_id = Ahoroscope_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Upd_prepaid_card`
--

DROP PROCEDURE IF EXISTS `Upd_prepaid_card`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Upd_prepaid_card`(
In Aprepaidcard_id  integer,
In Aprepaidcard_amount float,
In Aprepaidcard_currency varchar(45),
In Aprepaidcard_expired_date datetime,
In Aprepaidcard_status boolean
)
BEGIN
Update prepaid_card
set prepaidcard_amount = Aprepaidcard_amount,
prepaidcard_currency=Aprepaidcard_currency,
prepaidcard_expired_date=Aprepaidcard_expired_date
where prepaidcard_id = Aprepaidcard_id;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Upd_tag`
--

DROP PROCEDURE IF EXISTS `Upd_tag`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Upd_tag`(
In Atag_id integer,
In Atag_description varchar(50)
)
BEGIN
Update tag
set tag_description = Atag_description
where tag_id=Atag_id;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
