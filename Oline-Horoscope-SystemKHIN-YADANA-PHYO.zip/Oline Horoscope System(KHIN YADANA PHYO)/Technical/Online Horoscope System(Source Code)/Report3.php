<?php
      session_start();   //starting session   
if($_SESSION['admin_username'])
{
                
?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Most fortelling category and tag report</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
              
  <meta charset="utf-8">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\themes\base\jquery-ui.css">
  <script src="\\jquery-ui-1.10.4\jquery-1.10.2.js"></script>
  <script src="\\jquery-ui-1.10.4\ui/jquery-ui.js"></script>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\demos\demos.css">
  <script>
  $(function() {                
    $( "#datepicker" ).datepicker({dateFormat: 'yy-mm-dd'});
  });
  </script>
  <script>
  $(function() {
    $( "#datepickerend" ).datepicker({dateFormat: 'yy-mm-dd'});
  });
  </script>
    </head>
         
    <body style="text-align:center">
<form name="BS" id="BS" action="" method="post">  

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
                <!--Menu-->
        <?php
            include('Menu.php');
        ?>
        
        <!--Body-->
        <div class="body">
                <table align="center" class="param">
                <tr>
                    <td>Year:</td>
                    <td>
                      
                       <select name="month">
                            <option value="1">Janurary</option>
                            <option value="2">Feburary</option> 
                            <option value="2">March</option> 
                            <option value="2">Aprial</option> 
                            <option value="2">May</option> 
                            <option value="2">June</option>
                            <option value="2">july</option> 
                            <option value="2">August</option> 
                            <option value="2">September</option>   
                            <option value="2">October</option>
                            <option value="2">November</option>
                            <option value="2">December</option>   
                       </select>
              
                    </td>                           
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Month:</td>
                    <td>
                      
                        <select name="year">
                            <option value="2014">2007</option>  
                            <option value="2014">2008</option>  
                            <option value="2014">2009</option>  
                            <option value="2014">2010</option>  
                            <option value="2014">2011</option>  
                            <option value="2014">2012</option>  
                            <option value="2014">2013</option>  
                            <option value="2014">2014</option>  
                            <option value="2014">2015</option>
                            <option value="2014">2016</option>
                            <option value="2014">2017</option>    
                        </select>
              
                    </td>                           
                    <td><input type="submit" name="view" value="View"/></td>
                    <td></td>
                </tr>
            </table>            
            
        <!--Body-->
      <!--<div class="body">
              <table align="center" class="param">
                <tr>
                    <td>Choose Month & Year:</td>
                    <td>
                        <select name="month" id="month" style="width:190px">
                        <option value="Choose Month">Janurary</option> 
                        </select>
                        <select>
                                                <option value="Choose Month">2013</option> 
                        </select>
                    </td>                           
                    <td><input type="button" name="view" value="View"/></td>
                    <td></td>
                </tr>
            </table>            
            <table align="center" class="rpt">              
                    <tr>
                    <td><img style="width:100px; height:100px;" src="Image/logo.gif"/></td>
                    <td colspan="4"><b><u>Most fortelling category and tag report for the Month of December</u></b></td>   
                </tr>
                <tr style="text-align:right;">
                    <td colspan="6">Report Date: 31/december/2013</td>                       
                </tr> 
                <tr>
                    <td class="rpt">Horoscope</td>
                    <td class="rpt">Category</td>
                    
                     

                    <td class="rpt">Time asking</td>
                </tr>                                    
                <tr>
                    <td class="rptData">Pieces</td>
                    <td class="rptData">love</td>                     
                    
                     
                    <td class="rptData">65</td>
                </tr>
                <tr>
                    <td class="rptData">Leo</td>
                    <td class="rptData">Education</td>                     
                    
                    
                    <td class="rptData">55</td>
                </tr>
                <tr>
                    <td class="rptData">Cancer</td>
                    <td class="rptData">Health</td>                     
                    
                                       
                    <td class="rptData">25</td>
                </tr>
                <tr>
                    <td class="rptData">Virgo</td>
                    <td class="rptData">General</td>                     
                    
                     
                    <td class="rptData">10</td>
                </tr>
               

                    <td></td>
                    <td></td>
                </tr>                                   
            </table> -->
         
                                                                              
      <?php

 if ($_POST['view'] == "View")         //Clicking view button 
 {       
     if(isset($_POST['year']))            //Get data 
        $year = $_POST['year'];
         else
        $year="";
        if(isset($_POST['month']))
         $month=$_POST['month'];
        else
        $month="";
    
       $conn = new PDO("mysql:host=localhost;dbname=online_horoscope_system",'root' );      //Getting connection and calling Stored Procedure    
        $sql="Call Rpt_timeasking('$year','$month')";
        $q = $conn->query($sql);
        $q->setFetchMode(PDO::FETCH_ASSOC); 
  //  $GET_Item=mysql_query($sql) or die(mysql_error());
               
                                                               
    echo '<table align="center" class="rpt">';
        echo '<tr>';
                echo '<td><ilmg style="width:100px; height:100px;" src="Image/logo.gif"/></td>';
                echo '<td colspan="3"><b><u>Most fortelling category and tag report</u></b></td>';   
       echo '</tr>';
        
        echo '<tr>';                            //table header Name 
        echo '<th class="rpt"> Horoscope </th>'  
            .'<th class="rpt"> Category </th>'
            .'<th class="rpt"> Time Asking </th>';         
        echo '</tr>';

  
         
      while($r=$q->fetch())          //Calling data by looping    
  {        
        echo  '<tr>'; 
      echo '<td class="rpt">'.$r['horoscope_description'].'</td>' 
          .'<td class="rpt">'.$r['tag_description'].'</td>'
          .'<td class="rpt">'.$r['Time_asking'].'</td>';   
      echo '</tr>';

  }
        
      
       echo '</table>';
                                                    
 }
 
?>
            
         </div>                                                                      
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
             
            <a class="menu" href="Help.php">Help</a>  
            <br/>
        � KYDNP
        </div>
 </form>       
        
    </body>
</html>
<?php
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
    ?>