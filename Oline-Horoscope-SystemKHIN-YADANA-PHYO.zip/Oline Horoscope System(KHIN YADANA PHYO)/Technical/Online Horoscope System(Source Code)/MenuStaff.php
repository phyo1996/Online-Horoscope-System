<?php
   if ($_SESSION['admin_username'])
            {   
                ?>
              <!--  <a class="menu" href="Report.php">Reports</a> |-->
                <a class="menu" href="Horoscope_registration.php">Manage Horoscope</a> |  
                <a class="menu" href="Tag_registration.php">Manage Tag</a> | 
                   <a class="menu" href="prepaidcard_registration.php">Manage Prepaid Card</a> |   
                <a class="menu" href="Astology_registration.php">Manage Astology</a> | 
                <a class="menu" href="logout.php">Log-Out </a> .                
        <?php   
            }
            else
            {
        ?>
            <ul>
                <a class="menu" href="Home Page.php">Home</a> |
                <a class="menu" href="Registration.php">Register</a> |
                <a class="menu" href="login.php">Log-In </a> |
                <a class="menu" href="Billing Form.php">Billing Form</a>  
            </ul>                                               
        <?php
            }
        ?>            
