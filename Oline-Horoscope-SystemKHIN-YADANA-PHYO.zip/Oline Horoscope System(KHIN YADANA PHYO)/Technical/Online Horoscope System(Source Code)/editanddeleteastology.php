<?php
  require_once("connection.php");
  // $con=mysql_connect('localhost','root','');
  // mysql_selectdb('yhg', $con);
  function astology($astology_id)
{
    $output = mysql_query("SELECT * FROM astology WHERE astology_id ='$astology_id'");
    $Horo = mysql_fetch_row($output);
    return $Horo;
}
$update_adminID =1;

    if (isset($_POST['aid']))                         
   $astology_id=$_POST['aid'];               
  else                                                          
  $astology_id="";  
  
 // $astology_id = $_GET['id'];                                  
  
  if (isset($_POST['astology_description']))                         
   $astologydescription=$_POST['astology_description'];               
  else                                                          
  $astologydescription="";  
  
    if (isset($_POST['horoscope_name']))                         
   $horoscope_id=$_POST['horoscope_name'];               
  else                                                          
  $horoscope_id="";   
  
     if (isset($_POST['tag_name']))                         
   $tag_id=$_POST['tag_name'];               
  else                                                          
  $tag_id="";    
   
    if (isset($_POST['price']))                         
   $price=$_POST['price'];               
  else                                                          
  $price="";   
    $daily_horoscope=0;
     $monthly_horoscope=0;
     $annually_hroscope=0;                                
   if (isset($_POST['status']) == "1"){                         
   $daily_horoscope=1;
   }               
  else if(isset($_POST['status']) == "1")  {
     $monthly_horoscope = 1;
  }                                                
  else
  {
  $annually_hroscope = 1;
  }
  
                                                                
                                                        

   
$adminid=$_SESSION['adminid']; 
                                           
$astology =  astology($astology_id);                                 
                                                      
 if($astology)                                                    
{                                                               
    echo "'Astology updated successfully";
  $sql = "call Upd_astology('$astology_id','$horoscope_id','$tag_id','$astologydescription','$price','$daily_horoscope','$monthly_horoscope','$annually_hroscope','$update_adminID')";    

  if (mysql_query($sql))
  {
      $message = 'astology successfully';
  }                                                                                                                                                                     
  else
  {
      $message = mysql_error();
  }
}
else
{
    echo "No existing astology information";
$sql = "call Ins_astology('$horoscope_id','$tag_id','$astology_description','$price','$daily_horoscope','$monthly_horoscope','$annually_hroscope','$adminid')";                                              
      $r = mysql_query($sql);
                                                
if(!$r)
{
        $message = mysql_error();
}
else
{
    //header("location: Hotel_Information.php");
    $message = "astology is successfully saved!";    
}

}
?>

<h3><?php
//echo "[$sql]";
    echo $message;
?></h3>
<a href="Astology_registration.php">OK</a>
