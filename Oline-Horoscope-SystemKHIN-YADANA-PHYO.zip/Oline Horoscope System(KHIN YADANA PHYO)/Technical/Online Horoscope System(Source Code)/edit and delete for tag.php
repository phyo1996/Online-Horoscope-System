<?php
  require_once("connection.php");
  // $con=mysql_connect('localhost','root','');
  // mysql_selectdb('yhg', $con);
  
 
    
  function tag($tag_id)
{
    $output = mysql_query("SELECT * FROM tag WHERE tag_id= '$tag_id'");
    $Horo = mysql_fetch_row($output);
    return $Horo;
}
                                          
                              
    if (isset($_POST['ttag_id']))        
    $tid=$_POST['ttag_id']; 
    else                                            
    $tid="";
      
  if (isset($_POST['tag_description']))                         
   $tdescription=$_POST['tag_description'];               
  else                                                          
  $tdescription="";  
   
$tag= tag($tid);    
                                                                  
                                                  
 if($tag)                                                    
{                                                               
    echo "Tag updated successfully";
  $sql = "call Upd_tag('$tid','$tdescription')";  
  
  if (mysql_query($sql))
  {
      $message = 'Tag successfully';
  }
  else
  {
      $message = mysql_error();
  }
}
else
{
    echo "No existing tag information";
$sql = "call Ins_tag('$tdescription')";
    
      $r = mysql_query($sql);
                                                
if(!$r)
{
        $message = mysql_error();
}
else
{
    //header("location: Hotel_Information.php");
    $message = "Tag is successfully saved!";   

}

}
?>

<h3><?php
//echo "[$sql]";
    echo $message;
?></h3>
<a href="Tag_registration.php">OK</a>
