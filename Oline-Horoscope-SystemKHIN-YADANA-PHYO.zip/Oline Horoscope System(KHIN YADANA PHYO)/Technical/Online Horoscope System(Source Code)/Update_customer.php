<?php
          session_start();
if($_SESSION['username'])
{
   require_once ("session.php");      //call session
  require_once("connection.php");     //call connection
  
  
  $con=mysql_connect('localhost','root');    //connection database
  mysql_selectdb('online_horoscope_system', $con);   //select database
  
  $username = $_SESSION['username'];        //call customer session 
  echo "username_".$username."|";
  
    if (isset($_POST['customer_name']))
   $customer_name=$_POST['customer_name'];
  else
    $customer_name="";
    
    if (isset($_POST['customer_DOB']))
   $customer_DOB=$_POST['customer_DOB'];
  else
    $customer_DOB="";                                  
    
    if (isset($_POST['customer_username']))
   $customer_username=$_POST['customer_username'];
  else
    $customer_username="";
    
    if (isset($_POST['customer_password']))
   $customer_password=$_POST['customer_password'];
  else
    $customer_password="";
    
    if (isset($_POST['RegisterDate']))
   $customer_RegisterDate=$_POST['RegisterDate'];
  else
    $customer_RegisterDate="";
    
        if (isset($_POST['customer_gender']))
   $customer_gender=$_POST['customer_gender'];
  else
    $customer_gender="";
    
        if (isset($_POST['customer_country']))
   $customer_country=$_POST['customer_country'];
  else
    $customer_country="";
    
        if (isset($_POST['customer_NRC']))
   $customer_NRC=$_POST['customer_NRC'];
  else
    $customer_NRC="";
    
        if (isset($_POST['customer_address']))
   $customer_address=$_POST['customer_address'];
  else
    $customer_address="";
    
            if (isset($_POST['customer_email']))
   $customer_email=$_POST['customer_email'];
  else
    $customer_email="";
      
      
  
    function GetCustomerByID($UN)              //building function
{
    $customer_id = mysql_query("SELECT * FROM customer WHERE Customer_Username = '$UN'");   // counting rows
    $cust = mysql_fetch_row($customer_id);     //building array
    return $cust;   //Returns
}
  
  $cus_id = GetCustomerByID($username);

if(!is_null($cus_id))
{
   $cid = $cus_id[0];   
   $c_name = $cus_id[1];
   $c_dob = $cus_id[2];
   $c_username = $cus_id[3];
   $c_password = $cus_id[4];
   $c_rdate = $cus_id[5];
   $c_gender = $cus_id[6];
   $c_country = $cus_id[7];
   $c_nrc = $cus_id[8];
   $c_addr = $cus_id[9];
   $c_bal = $cus_id[10];
   $c_email = $cus_id[11];
   echo "customer id_".$cid."|";
}
else
{    
   $cid = "";   
   $c_name = "";
   $c_dob = "";
   $c_username = "";
   $c_password = "";
   $c_rdate = "";
   $c_gender = "";
   $c_country = "";
   $c_nrc = "";
   $c_addr = "";
   $c_bal = "";
   $c_email = "";
   echo "No cid!";
}
 
  
  If (isset($_POST['Update'])=="Update")      
{
    echo "Update Click!";

  $sql = "call Upd_customer('$cid','$customer_name','$customer_DOB','$customer_username','$customer_password', '$customer_gender','$customer_country','$customer_NRC','$customer_address','$customer_email');";  
  
  if (mysql_query($sql))
  {
      $message = 'Customer updated successfully';          //show message
  }
  else
  {
      $message = mysql_error();
  }
}
else 
{
    echo "No Click!|";
    
}
  
  function PageLoad($UID)            // building function
{
    $customer_id = mysql_query("SELECT * FROM customer WHERE Customer_Username = '$UID'");  //counting rows
    $cust = mysql_fetch_row($customer_id);   //building array
    return $cust;         //Returns
}
 


$customer = PageLoad($username);

if (!is_null($customer))
{
   $c_id = $customer[0];
   $c_name = $customer[1];
   $c_dob = $customer[2];
   $c_username = $customer[3];
   $c_password = $customer[4];
   $c_rdate = $customer[5];
   $c_gender = $customer[6];
   $c_country = $customer[7];
   $c_nrc = $customer[8];
   $c_addr = $customer[9];
   $c_bal = $customer[10];
   $c_email = $customer[11];
   echo $c_id;
}
else
{
    
   $c_id = "";
   $c_name = "";
   $c_dob = "";
   $c_username = "";
   $c_password = "";
   $c_rdate = "";
   $c_gender = "";
   $c_country = "";
   $c_nrc = "";
   $c_addr = "";
   $c_bal = "";
   $c_email = "";
}
//$Client = GetCustomerByID($customerscopeid);

?>
<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Update Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>
    <form method="post">


        <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>         
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
        <? include('Menu.php'); ?>
             <div style="width:100px; heigh:10px; margin-left:250px; margin-top:150px; margin-bottom:50px; border-style:dotted; border_width:1px; border-color:pink; text-align:right; padding-right:50px; float:left;" > <img src="Image/43.gif" ></img></div>   
        <div class="body">

        <div style="width:300px; heigh:100px; margin-left:250px; margin-top:50px; margin-bottom:50px; border-style:dotted; border_width:1px; border-color:pink; text-align:right; padding-right:50px;"> 
        <?
    
?>
Name<input type="text" name="customer_name" value="<?php echo $c_name ?>"></br>
Date of birth <input type="text" name="customer_DOB" value="<?php echo $c_dob ?>"></br>
UserName <input type="text" name="customer_username" value="<?php echo $c_username ?>"></br>
Password<input type="text" name="customer_password" value="<?php echo $c_password ?>"></br>
Registered Date<input type="text" name="RegisterDate" value="<?php echo $c_rdate ?>" readonly="true"></br>
Gender<select id="customer_gender" value="<?php echo $c_gender ?>">                                                     
<option>Male</option>
<option>Female</option>
</select></br>
Country<input type="text" name="customer_country" value="<?php echo $c_country ?>"></br>
NRC<input type="text" name="customer_NRC" value="<?php echo $c_nrc ?>"></br>
Address<input type="text" name="customer_address" value="<?php echo $c_addr ?>"></br>
Email<input type="text" name="customer_email" value="<?php echo $c_email ?>"></br>

<input type="submit" id="Update" name="Update" value="Update">
</div>
        
        </div>

        <!--Footer-->
        <div class="footer" style="float:left; margin-right: 50px; margin-top:20px;" >   
            <a class="menu" href="Aboutus.php">About Us</a> |

            <a class="menu" href="HelpCentre.php">Help</a>  
        <br/>
        <div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div>
        </div>
        
        </body>
</form>
</html>

<?php
 
//echo "[$sql]";
    echo $message;
?>
<?php
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
    ?>


