<?
session_start();          //starting sessin
include('connection.php');        // calling connecion page
function confirmUser($username, $password)       // building function
{
	global $connection;
	//add slashes for wirting query
	if(!get_magic_quotes_gpc())
		$username	=addslashes($username);;
             //identify that user is in database 
	$q	="SELECT customer_password from customer where customer_username='$username'";
	$result	=mysql_query($q,$connection);
    $a = mysql_num_rows($result);
	if(!$result || (mysql_numrows($result)<1))
		return 1;                                   //indicate customer username if fail
	//retrieve password from result, strip slashes
	$dbarray	=mysql_fetch_array($result);
	$dbarray['customer_password']	=stripslashes($dbarray['customer_password']);
	$password				=stripslashes($password);
    	
	//validate that password is correct
    
    
    
	if($password== md5($dbarray['customer_password']))      // encrypt the customer password
        return '0';                                         //success , customer username_name and customer password confirmed
	else 
        return "2";                         // indicate password if fail
    
}
function checkLogin()
{
	
	if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookpass']))      //check if user has been remembered 
	{
		$_SESSION['username']=$_COOKIE['cookname'];
		$_SESSION['password']=$_COOKIE['cookpass'];
	}
                                                                            //username and password has been set  
	if(isset($_SESSION['username']) && isset($_SESSION['password']))
	{
		                                                            //confirming that both username and password  are valid
		if(confirmUser($_SESSION['username'],$_SESSION['password'])!=0)
		{
			                                                        //variables are incorrect if user not logged in
			unset($_SESSION['username']);
			unset($_SESSION['password']);
			return false;
		}
		return true;
	}
	else return false;
}
	?>
    <?php
function displayLogin()
{
    global $logged_in;
    if($logged_in)
    {
        //echo "<h1>Logged In</h1>";
        //echo "Welcome <b>".$_SESSION['username']."</b> you are logged in.<a href=\"logout.php\">Logout</a>";
        echo "<script> window.location = 'Realaskingform.php' </script>";
    }
    else
    {
    ?>
<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Log in Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>
    <form method="post">
    <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D" > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
<? include('Menu.php')?>
        
        <!--Body-->
        <div class="body">
           <table style="margin-top:20px;" align="center" class="rpt" width="20px">              
                <tr>
                    <td><img style="width:100px; height:100px;" src="Image/logo.gif"/></td>
                 </tr>  
               
                <tr>
                    <td class="rpt">User Name:</td>
                    <td><input type="text" name="user" maxlength="30" /></td>                     
                </tr>                                    
                <tr>
                    <td class="rpt">Password:</td>
                    <td><input type="password" name="pass" maxlength="30"/></td> 
                </tr> 
                <tr>
                <td colspan="2" align="left">
                    <input type="checkbox" name="remember">
                    <font size="2">Remember me next time</font>
                </td>
                </tr>
                <tr>
                    <td ></td>
                    <td ></td>  
                    <td><input type="submit" name="sublogin" value="GO!"/> </td>                  

                </tr>   
               <tr>
                    <td ></td>
                    <td ></td>  
                    <td><a href="staff_login.php">Log-in[Staff]</a> </td>                  

                </tr >
                                                
            </table> 
         </div>      
             
            
        <!--Footer-->
        
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
            <a class="menu" href="HelpCentre.php">Help</a>  
            <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div>
        </div>

    </body>
                <?
    }
}    
if(isset($_POST['sublogin']))
{
    //check that all fields were typed in
    if(!$_POST['user'] || !$_POST['pass'])
    {
        die('You didn\'t fill in a required field.');
    }
    //spruce up username,check length
    $_POST['user']=trim($_POST['user']);
    if(strlen($_POST['user'])>30)
    {
        die("sorry, the usename is longer than 30 characters");
    }
    //check username is in database and password is correct
    $md5pass    =md5($_POST['pass']);
    
    $result        =confirmUser($_POST['user'],$md5pass);
    //check error code
    if($result ==1)
    die('That username doesn\'t exist in our database');
    else if($result==2)
    die('Incorrec password, please try again');
    //username and password correct, registersession variables
    $_POST['user']    =stripslashes($_POST['user']);
    $_SESSION['username']=$_POST['user'];
    $_SESSION['password']=$md5pass;
    
    if(isset($_POST['remember']))
    {
        setcookie("cookname",$_SESSION['username'],time()+60*60*24*100);
        setcookie("cookpass",$_SESSION['password'],time()+60*60*24*100);
    }
    //quick self-redirect to avoid resending data on refresh
    echo "<meta http-equiv=\"Refresh\" content=\"0;url=$HTTP_SERVER_VARS[PHP_SELF]\">";
    return;
}
//set the value of the logged_in variable , which can be used im your code
$logged_in=checkLogin();
?>
<? displayLogin(); ?>
    </form>
</html>
	
