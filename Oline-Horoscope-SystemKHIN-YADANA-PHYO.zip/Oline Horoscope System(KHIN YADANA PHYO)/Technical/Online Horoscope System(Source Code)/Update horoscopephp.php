<?php
    require_once("connection.php");
    require_once("session.php");
    
    if (isset ($_POST['submit']))
    {
        $error = Array();
        if ($_POST['name']<'6' )
        {
            
            $errors[]='Your Name is too short & Please type again';
          // window.alert($error[]);
        }
    }
  
?> 
<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>

    <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D" > 
        <tr><td>
            <marquee direction =right font-color=pink > Warmly Welcome</marquee>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
        <div class="navi">
        <ul>
            <a class="menu" href="Home Page.php5">Home</a> |
            <a class="menu" href="Registration.php">Register</a> |
            <a class="menu" href="Billing Form.php">Billing Form</a> |
            <a class="menu" href="Login.php">Log-In </a> .
        </ul>
        </div>
        
        <!--Body-->
<div class="body">
                
           <table align="center" class="rpt" width="50px">              
                <tr>
                    <td><img style="width:100px; height:100px;" src="Image/logo.gif"/></td>
                 </tr>   
               
                <tr>
                    <td class="rpt">Horoscope Description</td>
                    <td><input type="text" name="horodescription" /></td>

                </tr>                                    
                <tr>
                    <td class="rpt">Astology Description:</td>
                    <td><input type="password" name="astologydescription"  /></td>

                </tr> 
                <tr>
                    <td ></td>
                    <td ></td>  
                    <td><input type="submit" name="Update!" value="Update!"/> </td>                  

                </tr>   
               
                                                
            </table> 
         </div>      
      <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
             
            <a class="menu" href="Help.php">Help</a>  
            <br/>
        � KYDNP
        </div>

    </body>
</html>