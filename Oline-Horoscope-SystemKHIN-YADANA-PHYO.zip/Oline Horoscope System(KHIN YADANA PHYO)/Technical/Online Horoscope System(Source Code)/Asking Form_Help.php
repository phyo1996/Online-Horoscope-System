<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Asking Form for Help </title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>

    <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D" > 
        <tr><td>
            <marquee direction =right font-color=pink > Warmly Welcome</marquee>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->

        <!--Body-->
<div class="body">
<table id="help" style="height:100 width:100">
<tr>
      <h3>Asking Form</h3>
     <ol id="a">
     

    <li  >After you log-in, you can go to the asking form</li>
    <li  >When we ask the astrology,we can choose the 2 essential things such as categories and duration.</li>
    <li>  And then, we are ready to ask </li>
    
              </ul>
                   </ol>  
       
 
      </tr>
</table>
</div>   
</br>
       
 <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
          
            <a class="menu" href="HelpCentre.php">Help</a>  
            <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div> 

    </body>
</html>