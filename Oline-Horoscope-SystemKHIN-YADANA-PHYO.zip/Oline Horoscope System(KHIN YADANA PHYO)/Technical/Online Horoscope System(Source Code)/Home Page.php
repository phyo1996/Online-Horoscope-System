<?php
    session_start();
        if (($_POST['trust']))
        {                                                            
        echo '<script>window.location="Billing Form.php"</script>';
         }
    
?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>
    <form method="post">

    <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
        <? include('Menu.php'); ?>
        
        
        <!--Body-->
        <div class="body" >
          <table align="left"  width="950px" height="500px" >         

         <tr style="color: pink; font-family: Comic Sans MS;  font-size:28px">     
       <td >Trust</td> 
       <td > </td>
       <td ></td>
       
       <td ></td> 
       <td > </td>
       <td ></td>
       
       <td ></td> 
       <td > </td>
       <td ></td>
       </tr>
               <tr style="color: pink; font-family: Comic Sans MS;  font-size:28px">   
       <td ></td> 
       <td > </td>
       <td ></td>
       
       <td ></td> 
       <td >Me </td>
       <td ></td>
       
       <td ></td> 
       <td > </td>
       <td ></td>
       </tr>
       
                <tr>    
                      <td ></td> 
       <td > </td>
       <td ></td>
       
       <td ></td> 
       <td ></td>
       <td ></td>
       
       <td ></td> 
       <td > </td>
       <td ><td id="g"> <input type="submit" value="Trust" name="trust"></td>   </td>
       
       </tr>
       </table>
       </form>
                </div>                                                                      
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |

            <a class="menu" href="HelpCentre.php">Help</a>  
        <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div>
        </div>
      
    </body>
</html>
