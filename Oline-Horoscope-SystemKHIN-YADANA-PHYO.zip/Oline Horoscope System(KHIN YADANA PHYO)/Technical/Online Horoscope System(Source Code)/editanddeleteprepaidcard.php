<?php
  require_once("connection.php");
  // $con=mysql_connect('localhost','root','');
  // mysql_selectdb('yhg', $con);
  function prepaidcard($prepaidcard_id)
{
    $output = mysql_query("SELECT * FROM prepaid_card WHERE prepaidcard_id ='$prepaidcard_id'");
    $prepaidcard = mysql_fetch_row($output);
    return $prepaidcard;
}
    if (isset($_POST['prepaidcard_id']))                         
   $prepaidcard_id=$_POST['prepaidcard_id'];               
  else                                                          
  $prepaidcard_id="";                                       
  
  if (isset($_POST['prepaidcard_amount']))                         
   $prepaidcard_amount=$_POST['prepaidcard_amount'];               
  else                                                          
  $prepaidcard_amount="";  
  
    if (isset($_POST['prepaidcard_currency']))                         
   $prepaidcard_currency=$_POST['prepaidcard_currency'];               
  else                                                          
  $prepaidcard_currency="";   
  
     if (isset($_POST['prepaidcard_expired_date']))                         
   $prepaidcard_expired_date=$_POST['prepaidcard_expired_date'];               
  else                                                          
  $prepaidcard_expired_date="";    
   
/*    if (isset($_POST['prepaidcard_status']))                         
   $prepaidcard_status=$_POST['prepaidcard_status'];               
  else                                                          
  $prepaidcard_status="";             */
  
$prepaidcard_status = 1;
                                           
$astology =  prepaidcard($prepaidcard_id);                                 
                                                      
 if($astology)                                                    
{                                                               
    echo "'prepaidcard updated successfully";
  $sql = "call Upd_prepaid_card('$prepaidcard_id','$prepaidcard_amount','$prepaidcard_currency','$prepaidcard_expired_date','$prepaidcard_status')";    

  if (mysql_query($sql))
  {
      $message = 'prepaidcard successfully';
  }
  else
  {
      $message = mysql_error();
  }
}
else
{
    echo "No existing prepaidcard information";
$sql = "call Ins_prepaid_card('$prepaidcard_id','$prepaidcard_amount','$prepaidcard_currency','$prepaidcard_expired_date','$prepaidcard_status')";                                                  
      $r = mysql_query($sql);
                                                
if(!$r)
{
        $message = mysql_error();
}
else
{
    //header("location: Hotel_Information.php");
    $message = "prepaidcard is successfully saved!";    
}

}
?>

<h3><?php
//echo "[$sql]";
    echo $message;
?></h3>
<a href="prepaidcard_registration.php">OK</a>
