<?php
   session_start();
?>
<html>
    <head>
       <link rel="stylesheet" type="text/css" href="CSS/Test.css" />     
       </head>       
        <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->

        <?php
            include('Menu.php');
            
        $client_name=$_POST['name'];
        $client_DOB=$_POST['date'];
        if($_POST['day'] == true){
        $Adstats = 1;
        $Amstats = 0;
        $Aystats = 0;    
        }
        if($_POST['month']== true){
        $Adstats = 0;
        $Amstats = 1;
        $Aystats = 0;    
        }
        if($_POST['year']== true){
        $Adstats = 0;
        $Amstats = 0;
        $Aystats = 1;    
        }
        //$Adstats=$_POST['day'];    
        // $Amstats=$_POST['month'];
        //  $Aystats=$_POST['year'];
        $ATag_id=$_POST['what[]'];
        $Acid = $_SESSION['username'];
        
        
            
                $conn = new PDO("mysql:host=localhost;dbname=online_horoscope_system",
                      root);
                     //$sql = "call search_astology('$client_DOB','$ATag_id','$Adstats','$Amstats','$Aystats','$Acid')";
                     $sql = "call search_astology('$client_DOB','$Adstats','$Amstats','$Aystats','$ATag_id')";
                    //  $sql = "call search_astology('2014-1-1',1,1,0,0,1)";
                      $q = $conn->query($sql);
                      $q->setFetchMode(PDO::FETCH_ASSOC); 
        ?>
        <div style="width: 950px; height: 500px; margin-left:200px; margin-top: 20px; border-style: dotted;  border-width: 1px; border-color: pink;">
        <?php
            while($aa=$q->fetch())
               {
             echo'<div style="width:100px; height:50px; text-align: center;  margin-top:200px; border-color:orange; border-style: solid;  border-width: 1px; float: left;"><img src="Image/'.$aa['image_ID'].'"></img></div>';                      
             
             echo '<div style="width: 500px; height:410px; margin-left:250px; margin-top:50px; border-style:solid; border_width:1px; border-color:blue; float:left;">
                  '.$aa['astology_description'] .'</div> ';                      
             
               }
            ?>
          </div>

        
        <!--Footer-->
        <div class="footer" >   
            <a class="menu" href="Aboutus.php">About Us</a> |
          
            <a class="menu" href="Help.php">Help</a>  
            <br/>
        � KYDNP
        </div>

    
    </body>
</html>



















