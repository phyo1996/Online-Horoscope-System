<?php
     session_start();
?>
<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>

    <body style="text-align:center">

                      
        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->

        <!--Body-->
<div class="body">
<table id="help" style="height:100 width:100">
<tr>
      <h3>Registeration</h3>
     <ol id="a">
     

    <li  >At First, you must read the requirements to fill</li>
    <li  >And, we must fill the detail requirements in the form.</li>
    <li> After that, you must click "Let go register" and you register successfully</li>       
              </ul>
        
      </ol>
      </tr>
</table>
</div>  
<br />
       
        <!--Footer-->
        <div class="footer" >   
            <a class="menu" href="Aboutus.php">About Us</a> |
             
            <a class="menu" href="HelpCentre.php">Help</a>  
            <br/>
        � KYDNP
        </div>

    </body>
</html>