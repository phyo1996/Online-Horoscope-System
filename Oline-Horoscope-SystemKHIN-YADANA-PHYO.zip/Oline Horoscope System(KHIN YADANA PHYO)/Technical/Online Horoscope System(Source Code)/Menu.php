<?php
  session_start();
?>

<div class="navi">

        <?php
            if ($_SESSION['username'])
            {   ?>
                <a class="menu" href="Home Page.php">Home</a> |
                <a class="menu" href="Realaskingform.php">Asking Form</a> |
                <a class="menu" href="HelpCentre.php">Help</a> |
                <a class="menu" href="balance_menu.php">Balance</a> |  
                <a class="menu" href="Update_customer.php">Update profile</a>
                <a class="menu" href="logout.php">Log- Out </a> . 
       <?php
            }
            else {
       ?>
            <ul>
                <a class="menu" href="Home Page.php">Home</a> |
                <a class="menu" href="Registration.php">Register</a> |
                <a class="menu" href="login.php">Log-In </a> |
                <a class="menu" href="Billing Form.php">Billing Form</a>  
            </ul>                                               
        <?php
            }
        ?>            
       
</div>
