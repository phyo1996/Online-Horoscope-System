<?php
      session_start();
if($_SESSION['admin_username'])
{
session_start();
require_once('connection.php');
require_once('session.php');

?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>

    <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
        <?php
            include('MenuStaff.php');
        ?>
        <!--Body-->
        <div class="body">
        
              <a href="report1.php" name="new member registration"> New Member registration List </a>   <br />
              <a href="report2.php" name="new member registration"> The frequency of asking time and total charges </a>    <br />   
              <a href="report3.php" name="new member registration"> the monthly report for the most foretelling category </a>       
              
         </div>                                                                      
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
             
            <a class="menu" href="Help.php">Help</a>  
            <br/>
        � KYDNP
        </div>

    </body>
</html>
<?php
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
    ?>
    