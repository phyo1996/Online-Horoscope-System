<?php
    require_once("DB.php");
?>
<html>
<body >
<form name="BS" id="BS" action="" method="post">
<table align="center">
<tr>
 <td class="header" > <b><p><font color="black"> Item </font> </p></b></td> 
    <td >
        <select name="BindItem" > 
        <?php                                                                                  
       
            $a="SELECT Item_Id,Name FROM Item";
            $GET_Item=mysql_query($a);
            while($result=mysql_fetch_assoc($GET_Item))
            {                                                                                    
            ?>
            <option name="Item" value="<?php echo $result['Item_Id']; ?>"><?php echo $result['Name']; ?></option>
            <?php
            }
            echo "</select>";
            ?>

        </td>
 </tr>
 <tr>
 
 <td align="left"><input value="Search" name="Search1" class="btn_style1" type="submit"/><font size="4px"> </font> </td>          
 
</tr>
</table>
</form>
</body>
</html>  
<?php
        //When search button is clicked
 if ($_POST['Search1'] == "Search")
 {       //Get data from combo
     if(isset($_POST['BindItem']))   
        $Item = $_POST['BindItem'];
         else
        $Item="";
     //Get connection   and call Stored Procedure
       $conn = new PDO("mysql:host=localhost;dbname=projectsample",
                            root, root);  
        $sql="Call Sel_Itemcat('$Item')";
        $q = $conn->query($sql);
        $q->setFetchMode(PDO::FETCH_ASSOC); 
  //  $GET_Item=mysql_query($sql) or die(mysql_error());
    
    echo '<table border=1 align="center" bgcolor="blue">';
        //table header   Name
        echo '<tr>';
        echo '<th> Item_id </th>'  
            .'<th> Name </th>'
            .'<th> Price </th>' ;
                                                          

        echo '</tr>';

  
    //Call data by looping         
      while($r=$q->fetch())
  {        
   echo  '<tr>'; 
      echo '<td>'.$r['Item_id'].'</td>' 
          .'<td>'.$r['Name'].'</td>'
          .'<td>'.$r['Price'].'</td>';
      
      
      echo '</tr>';                          

  }
       echo '</table>';
    
 }
     








 