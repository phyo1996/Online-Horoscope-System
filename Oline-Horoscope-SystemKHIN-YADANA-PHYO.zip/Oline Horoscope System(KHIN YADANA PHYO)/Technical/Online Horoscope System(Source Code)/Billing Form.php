<?php
  session_start();                        
  require_once("connection.php");         //calling connection page
  require_once("session.php");             //calling session page
?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Billing Form</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>

    <body style="text-align:center">
<form action="" method="post">
                <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
        
        <?php
            include('Menu.php');
        ?>
        
        <!--Body-->
        <div class="body">
               <table style="width :500px" bgcolor="Pink">
                     <tr style="font-size: 40px;color: Olive;">
                     <td>Your PIN-No </td>
                     <td><input type="text" name="pinno"</td>
                     </tr>
                     <tr align="left">
                    <!--<a href="Home Page.html">Next step>>>>>></a>Please do instration in your card.-->
                    <input type="submit" name="submit" value="Go">
                      </tr>
                      <tr align="left">
                     <?php
      session_start();   
$cname=$_SESSION['username'];
 $cid=mysql_query("Select * FROM customer WHERE customer_username='$cname'");        // select query 
  $GET_cid = mysql_fetch_row($cid);
 $cusid=$GET_cid[0];
  if(isset($_POST['pinno']))
  $prepaidcard_id=$_POST['pinno'];
  
          
          If (isset($_POST[submit])  )       //Clicking submit
  {
   $checkcard ="SELECT * FROM prepaid_card where prepaidcard_status=1 And   prepaidcard_expired_date >= curdate() and prepaidcard_id = '$prepaidcard_id'";

$query = mysql_query($checkcard);
$result = mysql_num_rows($query);
if($result<1){
echo "Pin not exists!"; 
//$aa=mysql_fetch_assoc($query);
}
  else{
  
   $insbalance ="CALL ins_prepaid('$cusid','$prepaidcard_id');";        // Calling procedure
    if (mysql_query($insbalance))
  {
      echo "Pin exists";
  $c=mysql_query("SELECT * FROM customer WHERE customer_username='$cid'");
 $GET_bal=mysql_fetch_row($c);
 $balance=$GET_bal['Balance'];
      $message = 'Balance Added Successfully!';
      echo $message;                                                   // output message

  }
  else
  {
      $message = mysql_error();
  }
  
  }
  }

        ?>
                    </tr>
                     
        </table>
         </div>                                                                      
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |

            <a class="menu" href="HelpCentre.php">Help</a>  
            <br/>
<div>
<a href="#www.facebook.com"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#www.flickr.com"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#www.twitter.com"><img src="Image/twitter.png" alt="Twitter" /></a>
</div>
        </div>
</form>        
    </body>
</html>