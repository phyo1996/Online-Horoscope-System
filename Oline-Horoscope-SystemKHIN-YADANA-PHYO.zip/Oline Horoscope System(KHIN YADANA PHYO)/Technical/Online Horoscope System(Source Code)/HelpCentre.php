<?php
     session_start();
?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>

    <body style="text-align:center">
              
        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
        
        <?php
            include('Menu.php');
        ?>
        
        <!--Body-->
<html>

<title>Help Centre</title>
<style type="text/css">

 div.help2{
    border:15px solid Gainsboro  ;
    margin-left: 300px;
    width:300px;
   border-radius:35px; 
   text-align:left;
     
      }
h3{
    font: 1.2em bolder , Calibri;
    margin: 0;
    padding:1em 0;
    text-align:center;
    color: CC6600;
}
ul
{
list-style-type:none;

}
li
{
list-style-image:url("Image/bullet.png");

}

</style>
</head>      

    

<body>
<div id="main" style="margin-left:150px;">
<img    src="Image\Help.png" width="960px" height="150px" style="margin-right:140px">
  
  <div id="help" style="margin-top:100px"  >   
  
      <a href="download.php">Download User Manual</a>
     
         <div id="help1" class="help2" style="margin-bottom:40px; margin-left:75px;" >
      <h3>Log-in & Registration</h3>
     <ul id="a">
     

    <li  ><a href="First_Help.php" class="cozy" style="color: #99CCFF;">First</a></li>
    <li  ><a href="Log-in.--help.php" class="cozy" style="color: #99CCFF;">Log-in</a></li>
    <li  ><a href="registration_help.php" class="cozy" style="color: #99CCFF;">Registration</a></li>
              </ul>
      </div>    
      
       <div id="help1" class="help2" style="margin-left:600px;margin-top:-240px;margin-bottom:40px;">
      <h3>Asking Form & Payment </h3>
     <ul id="3d">            
     

    <li ><a href="Asking Form_Help.php" class="cozy" style="color: #99CCFF;">Asking Form</a></li>
    <li ><a href="Payment_help.php" class="cozy" style="color: #99CCFF;">Payment</a></li>
    <li  ><a href="upadte_help.php" class="cozy" style="color: #99CCFF;">Customer Update</a></li>
              </ul>
      </div>
  </div>
   </div>
  </body>

</html>

        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |

            <a class="menu" href="HelpCentre.php">Help</a>  
            <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div>
        </div>

    </body>
</html>