 <?php
  require_once("connection.php");
  //require_once("AutoID.php");
  
   function GetCustomerByID($customer_id)
{
    $output = mysql_query("SELECT * cROM customer WHERE customer_id = '$customer_id'");
    $customer = mysql_fetch_row($output);
    return $customer;
}
       



if (($_GET['action']) == 'Edit' && !empty($_GET['id']))  
{
    $Client =  GetCustomerByID($_GET['id']);
}


if (!is_null($Client))
{
     $customer_Id=$Client[0];
   $Customer_Name= $Client[1];
    $Customer_DOB= $Client[2];
   $Customer_Username= $Client[3];
   $Customer_Password= $Client[4];
   $Customer_Gender= $Client[5];
   $Customer_Country= $Client[6];
   $Customer_Nrc= $Client[7];
   $Customer_Address= $Client[8];
           
   
}

else
{           $customer_Id="";
   $Customer_Name= "";
    $Customer_DOB="";
   $Customer_Username="" ;
   $Customer_Password="";
   $Customer_Gender="";
   $Customer_Country="";
   $Customer_Nrc="";
   $Customer_Address="";
 
}

?>
 
<html>
<head>
<title> Horoscope Registration </title>   
<script language="javascript" type="text/javascript">
<script language="javascript" type="text/javascript">
function HoroscopelID_validation()
{
var CustomerID = document.f.horoscope_id.value;

    if (customer_id == '')
    {
         document.getElementById("Customer_id_lable").innerHTML="Please Fill Customer ID";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("Customer_id_lable").innerHTML="";
        //return true; 
    }
}


function CustomerName_validation()
{
var Customer_Name = document.f.customer_name.value;

    if (Customer_Name == '')
    {
         document.getElementById("customer_name_lable").innerHTML="Please Fill Hotel Name";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("customer_name_lable").innerHTML="";
        //return true; 
    }
}

function Customer_DOB_validation()
{
var Customer_DOB = document.f.customer_DOB.value;

    if (HoroscopeName == '')
    {
         document.getElementById("customer_DOB_lable").innerHTML="Please Fill Customer DOB";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("customer_DOB_lable").innerHTML="";
        //return true; 
    }
}

function Customer_UserName_validation()
{
var Customer_UserName = document.f.custoemr_username.value;

    if (HoroscopeName == '')
    {
         document.getElementById("custoemr_username_lable").innerHTML="Please Fill Customer UserName";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("custoemr_username_lable").innerHTML="";
        //return true; 
    }
}

function Customer_Password_validation()
{
var Customer_Password = document.f.customer_password.value;

    if (Customer_Password == '')
    {
         document.getElementById("customer_password_lable").innerHTML="Please Fill Hotel Name";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("customer_password_lable").innerHTML="";
        //return true; 
    }
}

function Customer_Gender_validation()
{
var Customer_Gender = document.f.customer_gender.value;

    if (Customer_Gender == '')
    {
         document.getElementById("customer_gender_lable").innerHTML="Please Fill Hotel Name";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("customer_gender_lable").innerHTML="";
        //return true; 
    }
}


function Customer_Country_validation()
{
var Customer_Country = document.f.customer_country.value;

    if (HoroscopeName == '')
    {
         document.getElementById("customer_country_lable").innerHTML="Please Fill customer country";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("customer_country_lable").innerHTML="";
        //return true; 
    }
}

function Customer_NRC_validation()
{
var Customer_NRC = document.f.customer_nrc.value;

    if (HoroscopeName == '')
    {
         document.getElementById("customer_nrc_lable").innerHTML="Please Fill Customer NRC";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("customer_nrc_lable").innerHTML="";
        //return true; 
    }
}

function Customer_address_validation()
{
var Customer_Address = document.f.customer_address.value;

    if (HoroscopeName == '')
    {
         document.getElementById("customer_address_lable").innerHTML="Please Fill cusotmer address";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("customer_address_lable").innerHTML="";
        //return true; 
    }
}

}  
</script>
  
</script>
</head>
 
<body bgcolor="silver">
  <table style="width:850px; margin-left:200px" class="header" bgcolor="#cDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header" style="margin-left:200px;">
        <img src="Image/banner.jpg" />
        </div>


        <div class="header1">
        <div class="HEADER" style="margin-left:200px;">  
        <a href="StaffHotel_Information.php" class="linktabHI" target="crame">Hotel Information</a>
        <a href="Hotel Report.php" class="linktab" target="crame">Report</a>     
        <a href="Hotel_Login.php" class="linktab" target="crame">LogOut</a> 
        </div>  
       
    <form action="edit and delete cor horoscope_php.php" method="post" id="f" name="c"> 
    <div class="body" style="height:580px">
            <table cellpadding="12" cellspacing="1" border="0" align="center" class="Param" style="height:245px"> 


            <tr >
                <td width="170px" style="font-family:Comic Sans MS">Customer Name:</td>
                <td width="100px"> <input type="text" name="customer_name" id="customer_name" onblur="CustomerName_validation()" /></td>
                <td width="200px"> <span id="customer_name_lable"></span>       </td>     
            </tr>
            
            <tr>
              /*  <td style="font-family:Comic Sans MS">Customer Email:</td>
                <td> <input type="pass" name="CustomerEmail" id="CustomerEmail" onblur="CustomerEmail_validation()" /></td>
                <td>  <span id="CustomerEmail_lable"></span>       </td>     
            </tr>*/

            <tr>
                <td style="font-family:Comic Sans MS"> Gender  </td>
                <td>   <input type="radio" name="customer_gender" id="male" value="1" >Male </br> 
                <input type="radio" name="customer_gender" id="female" value="0" >Female   </td>
                <td>  <span id="customer_gender_lable"></span>       </td>     
            </tr>
        <!--   <tr>
                <td style="font-family:Comic Sans MS">Date Of Birth :</td>
                <td><input type="text" value="1 Jan 2014" disabled="True"/> <img src="image/iconCalendar.gif">
                </td>
                <td>  <span id="Cname_lable"></span>       </td>                                              
            </tr> -->
                      <tr>
                    <td style="font-family:Comic Sans MS">Date of Birth:</td>
                    <td>
                      
                        <input name="start_date" type="text" id="datepicker" >
              
                    </td>                           
                    <td></td>
                    <td></td>
                </tr>
                <tr>
            <tr>
                <td style="font-family:Comic Sans MS">Country</td>
            <td>    <select name="country" value="day">
                        <option value="Amercia">Amercia</option> 
                        <option value="British">British</option> 
                        <option value="Canada">Canada</option> 
                        <option value="Myanmar">Myanmar</option>
                        <option value="USA">USA</option>    
                    </select>
            </td>
            <td>  <span id="Cname_lable"></span>       </td>                                              
            </tr>
                                <tr>
                <td style="font-family:Comic Sans MS">UserName:</td>
                <td> <input type="pass" name="username" id="username" onblur="Username_validation" /></td>
                <td>  <span id=""></span>       </td>     
            </tr>
            <tr>
                <td style="font-family:Comic Sans MS">Customer Password:</td>
                <td> <input type="pass" name="CustomerPassword" id="CustomerPassword" onblur="Password_validation()" /></td>
                <td>  <span id="Password_lable"></span>       </td>     
            </tr>
            
            <tr>
                <td style="font-family:Comic Sans MS">Customer Confiirmation Password</td>
                <td><input type="text" name="RetryPW" id="RetryPW" onblur="RetryPW_validation()" /></td>
                <td>  <span id="RetryPW_lable"></span>       </td>                                              
            </tr>

            <tr>
                <td style="font-family:Comic Sans MS">Customer NRC</td>
                <td><input type="text" name="NRC" id="NRC" onblur="CustomerNRC_validation()" /></td>
                <td>  <span id="CustomerNRC_lable"></span></td>                                              
            </tr>

            <tr>
                <td style="font-family:Comic Sans MS">Customer Adddress</td>
                <td><input type="text" name="CustomerAddress" id="CustomerAddress_validation" /></td>
                <td>  <span id="CustomerAddress_lable"></span>       </td>                                              
            </tr>
            <tr>
                <td colspan="3" align="center" valign="middle"> <input type="submit" id="submit" name="submit" value="Let go register" /></td>
            </tr>
            </table>   
         </div>  
    </corm>
</body>
</html>
<?php
       $a="SELECT  horoscope_id, horoscope_description
    crom horoscope";
    
    $GET_Horoscope=mysql_query($a);


    echo '<table border=1 align="center" >';
  
        echo '<tr><th>Horoscope ID</th>';
        echo '<th>Horoscope Description</th>';

      echo '</tr>';
      while($aa=mysql_fetch_assoc($GET_Horoscope))
  {
      echo  '<tr>'; 
      echo '<td>'.$aa['horoscope_id'].'</td>' 
      . '<td>'.$aa['horoscope_description'].'</td>' ;

      echo '<td>'.'<a href="Horoscope_Registration.php?action=Edit&id='.$aa['horoscope_id'].'
       &Name='.$aa['horoscope_name'].'">
      Edit</a>'.'</td>';
   echo '<td>'.'<a href="Horoscope_Registration.php?action=delete&id='.$aa['horoscope_id'].'">Delete</a>'.'</td>';
      echo '</tr>';
  }
       echo '</table>';
?>
  