<?php
session_start();
if($_SESSION['admin_username'])
{
session_start();
require_once('connection.php');
  //  require_once("session.php");
  //require_once("AutoID.php");
  
  function astology_id($astology_id)
{
    $output = mysql_query("SELECT * FROM astology WHERE astology_id = '$astology_id'");
    $Horo = mysql_fetch_row($output);
    return $Horo;
}

function DeleteForAstology($astology_id)
{
    $Delete = "Call del_astology('$astology_id')";
    return mysql_query($Delete);
}

if (($_GET['action']) == 'delete' && !empty($_GET['id']))  
{
    DeleteForAstology($_GET['id']);
    echo "Deletion of that Astrology is successful.";
}

$Horoscope = null;

if (($_GET['action']) == 'Edit' && !empty($_GET['id']))  
{
    $Horoscope =  astology_id($_GET['id']);
}



if (!is_null($Horoscope))
{
     $astology_id=$Horoscope[0];
   $horoscope_id = $Horoscope[1];
   $tag_id = $Horoscope[2];
   $astology_description = $Horoscope[3];
   $price = $Horoscope[4];
   $daily_horoscope = $Horoscope[5];
   $monthly_horoscope = $Horoscope[6];
   $annually_hroscope = $Horoscope[7];
   $update_adminID = $Horoscope[8];
}
else
{      $astology_id="";
    $horoscope_id = "";
   $tag_id = ""; 
   $astology_description  = ""; 
   $price = ""; 
   $daily_horoscope = ""; 
   $monthly_horoscope = ""; 
   $annually_hroscope = ""; 
   $update_adminID = ""; 
}

?>

 
<html>
<head>
<title> Astology Registration </title>   
<script language="javascript" type="text/javascript">

function HoroscopeName_validation()
{
var HoroscopeName = document.f.horoscope_name.value;

    if (HoroscopeName == '')
    {
         document.getElementById("horoscope_name_lable").innerHTML="Please Fill Hotel Name";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("horoscope_name_lable").innerHTML="";
        //return true; 
    }
}


function TagName_validation()
{
var tag_description = document.f.tag_name.value;

    if (tag_description == '')
    {
         document.getElementById("tagdescription_label").innerHTML="Please Fill Hotel Name";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("tagdescription_label").innerHTML="";
        //return true; 
    }
}

function Astology_description_validation()
{
var astology_description = document.f.astology_description.value;

    if (astology_description == '')
    {
         document.getElementById("astologydescription_label").innerHTML="Please Fill Astrology Description";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("astologydescription_label").innerHTML="";
        //return true; 
    }
}


function price_validation()
{
var price = document.f.price.value;

    if (price == '')
    {
         document.getElementById("price_label").innerHTML="Please fill astrology price";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("price_label").innerHTML="";
        //return true; 
    }
}
  
</script>
</head>
 
<body bgcolor="white">
 <table style="width:850px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php');?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header" style="margin-left:200px;">
        <img src="Image/banner.jpg" />
        </div>

       
    <form action="editanddeleteastology.php" method="post" id="f" name="f"> 
            <div class="header1" >
        <div class="HEADER" style="margin-left:200px;">  
        <a href="Report.php" class="linktab"  target="frame">Home</a>     
        <a href="logout.php" class="linktab" target="frame">LogOut</a> 
        </div>  
       
    <table width="500px" height="400px" align="center" style="border-style:solid; border-color:lightpink;">
        <tr>
               <td style="font-family:Comic Sans MS; color:olive;">Astology ID</td>
               <td><input type="text" name="aid" id="aid" onblur="" value="<?php echo  $astology_id; ?>" >
         </td>
               </tr>   
        <tr align="left">
        <td style="font-family:Comic Sans MS; color:olive; "> Horoscope Name </td>
       <td> <?php  
              echo "<select name='horoscope_name'>";
             
             $a="SELECT horoscope_id,horoscope_description FROM Horoscope";
            $GET_Horo=mysql_query($a);
            while($result=mysql_fetch_assoc($GET_Horo))
            {  

                                                                                   
            ?>
            <option name="horoscope_name" value="<?php echo $result['horoscope_id']; ?>" ><?php echo $result['horoscope_description']; ?></option>
            <?php
              }
            echo "</select>";?> </td>
        <span id="horoscope_name_lable"></span> </td>
        </tr>
         <tr  align="left">
        <td style="font-family:Comic Sans MS; color:olive;"> Tag Description </td>
        <td> <?php  
                   echo "<select name='tag_name'>";
        $a="SELECT * FROM tag";
            $GET_Tag=mysql_query($a);
            while($result=mysql_fetch_assoc($GET_Tag))
            {  
                                                                                
            ?>
            <option name="tag_name" value="<?php echo $result['tag_id']; ?>"><?php echo $result['tag_description']; ?></option>
            <?php
                }
            echo "</select>";?> </td>
        <span id="tagdescription_label"></span> </td>
        </tr>
        
          <tr align="left">
        <td style="font-family:Comic Sans MS; color:olive;"> Astology Descr </td>
        <td><input type="text" name="astology_description" id="astology_description" onblur="Astology_description_validation()" value="<?php echo  $astology_description; ?>">
        <span id="astologydescription_label"></span> </td>
        </tr>
        
                  <tr >
        <td style="font-family:Comic Sans MS; color:olive;"> Price </td>
        <td><input type="text" name="price" id="price" onblur="price_validation()" value="<?php echo  $price; ?>">
        <span id="price_label"></span> </td>
        </tr>
        
          <td style="font-family:Comic Sans MS; color:olive;">   
                <input type="radio" name="status" id="daily" value="0" >Daily Horoscope</br> 
                <input type="radio" name="status" id="monthly" value="0" >Monthly Horoscope</br>  
                <input type="radio" name="status" id="annually" value="1" >Annually Horoscope</br>
                </td>
                <td>   </td> 
                
        <tr>
             <td colspan="2" style="text-align:center"><input type="submit" value="Save">
        
        </tr>
    
    </table>
    </form>
</body>
</html>
<?php
       $a="select * from astology as a,tag as t,horoscope as h
Where  a.horoscope_id = h.horoscope_id
And     t.tag_id  =  a.tag_id";
    
    
    
    $GET_Horoscope=mysql_query($a);


  echo '<table border=1 align="center" >';
  
        echo '<tr><th>Astology ID</th>';
        echo '<th>Horoscope Name</th>';
         echo '<th>Tag Description</th>';
         echo '<th>Astrology Description</th>';
      echo '<th>Price</th>';
      echo '<th>Daily_Horoscope</th>';
      echo '<th>Monthly_Horoscope</th>';
      echo '<th>Annually_Horoscope</th>';
      echo '<th>update_adminID</th>';
      echo '</tr>';
      while($aa=mysql_fetch_assoc($GET_Horoscope))
  {
echo  '<tr>'; 
      echo '<td>'.$aa['astology_id'].'</td>' 
      . '<td>'.$aa['tag_description'].'</td>'
      . '<td>'.$aa['horoscope_description'].'</td>' 
      . '<td>'.$aa['astology_description'].'</td>'
      . '<td>'.$aa['price'].'</td>' 
      . '<td>'.$aa['daily_horoscope_status'].'</td>' 
      . '<td>'.$aa['monthly_horoscope_status'].'</td>' 
      . '<td>'.$aa['annually_horoscope_status'].'</td>'
      . '<td>'.$aa['update_adminID'].'</td>' ;

      echo '<td>'.'<a href="Astology_registration.php?action=Edit&id='.$aa['astology_id'].'"> 
      Edit</a>'.'</td>';
   echo '<td>'.'<a href="Astology_registration.php?action=delete&id='.$aa['astology_id'].'">Delete</a>'.'</td>';
      echo '</tr>';
  }
       echo '</table>';
?>
      <?php 
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
    ?>