<?php
    $host ="localhost";
    $username ="root";
    $password ="";
    $database = "online_horoscope_system";
    $connection =mysql_connect($host,$username);
    if($connection)
    {                       
        $connectdatabase =mysql_selectdb($database,$connection);
        if(!$connectdatabase)
        {
            die(mysql_error());
        }
        //echo 'connection successful';
    }
    else
    {
        die(mysql_error());
    
    }
    
 /**
    $sql= "SELECT customer_name FRom customer";
    

    $queryResult = mysql_query($sql);
    

     echo '<table border=1>';
echo '<tr>';
echo '<td> customer_name </td>';
echo '</tr>';

while ($row = mysql_fetch_assoc($queryResult))
{
echo '<tr>';
echo '<td>'.$row[customer_name].'</td>' ;                           
echo '</tr>';
}
echo '</table>';
**/
    ?>