<?php
      session_start();
if($_SESSION['username'])
{
    require_once("connection.php");   //call connection
    require_once("session.php");     //call session
   
   if(isset($_POST['name'])){
       $name =   $_POST['name'];
   }
   else{
       $name = '';
   }
   
    if(isset($_POST['date'])){
       $dob =   $_POST['date'];
   }
   else{
       $dob = '';
   }  
   
   
    $array_error = array();
if(isset($_POST['submit']) )      // if click button
      {
    //print_r($_POST);
                         
        $client_name=$_POST['name'];
        $client_DOB=$_POST['date'];
        if($_POST['day'] == true){
        $Adstats = 1;
        $Amstats = 0;
        $Aystats = 0;    
        }
        if($_POST['month']== true){
        $Adstats = 0;
        $Amstats = 1;
        $Aystats = 0;    
        }
        if($_POST['year']== true){
        $Adstats = 0;
        $Amstats = 0;
        $Aystats = 1;    
        }
        //$Adstats=$_POST['day'];    
        // $Amstats=$_POST['month'];
        //  $Aystats=$_POST['year'];
        $ATag_id=$_POST['what'];
        $Acid = $_SESSION['username'];
        
        if($client_name=='')
            $array_error[]='Please enter name & Good Luck!';    
            
        if($client_DOB=='')
            $array_error[]='Please fill your Date of Birth';
            
        if($client_status=='')
            $array_error[]='Select your status!';
            
                    if($client_tag=='')
            $array_error[]='Guess what!';
        if(count($array_error) == 0) 
            {
            
          
          }
            }
      
    
                
                if (  $client_array  ) 
                     {
                    
                        session_start();         // starting session
                        $_SESSION['session_asking'] = $client_array['client_id'];
                        header("location:Home Page.php");     //Go to another link
                        
                    }
                    else  {
                        $array_error[]='Email and password does not match!';
                        
            }  
            


            
    
                         

?>                             
<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
              <meta charset="utf-8">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\themes\base\jquery-ui.css">
  <script src="\\jquery-ui-1.10.4\jquery-1.10.2.js"></script>
  <script src="\\jquery-ui-1.10.4\ui/jquery-ui.js"></script>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\demos\demos.css">
  <script>
  $(function() {
    $( "#datepicker" ).datepicker({dateFormat: 'yy-mm-dd'});
  });
  </script>
  
  <script language="javascript" type="text/javascript">
           
function Name_validation()
    {
    var Name = document.Realaskingform.Name.value.length;
    alert('Please Fill Name!');
        if (Name == 0)
             document.getElementById("Name_lable").innerHTML="Please Fill Name!";
        else
            document.getElementById("Name_lable").innerHTML="";
    }
    
function DOB_validation()
    {
    var DOB = document.Realaskingform.date.value.length;
    alert('Please Fill DOB!');
        if (DOB == 0 )
             document.getElementById("Date_lable").innerHTML="Please Fill DOB!";
        else
            document.getElementById("Date_lable").innerHTML="";
    }
</script>
    </head>

    <body style="text-align:center">
    <form method="post">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>            
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />      
        </div>
        
        <!--Menu-->

        <?php
            include('Menu.php');
        ?>
        
        <!--Body-->
        <form action="Realshow.php" method="post">     
        <div class="body" style="height:700px;">
          <p style="text-align:center; font-size:16px;">Asking Form</p>                           
           <table align="center" width="60px" class="param" border="0">  
                    <td>Name :</td>
                    <td><input type="text" name="name" onblur="Name_validation()"/>
                    <span id="Name_lable"></span></td>
                </tr>
                     <tr>
                    <td>Date of Birth</td>
                    <td>
                      
                        <input name="date" type="text" id="datepicker" onblur="DOB_validation()" >
                        <span id="date_lable"></span>
                    </td>                           
                    <td></td>
                    <td></td>
                </tr>
             <!--   <tr>
                    <td>Date Of Birth :</td>
                    <td>
                    <input type="text" value="1 Jan 2014" disabled="True"/> 
                    <img src="image/iconCalendar.gif">
                    </td>
                </tr> -->   
            <!--<select name="day" value="day">
                    <option value="1">1</option>   
                    </select>
                    <select name="month" value="month">
                    <option value="1">Jan</option>   
                    </select>
                    <select name="year" value="year">
                    <option value="1">1900</option>   
                    </select>     
               -->   
                
                <tr>
                <td colspan="2" align="center"> Daily<input type="radio" name="day" />
                Monthly<input type="radio" name="month" />
                Yearly<input type="radio" name="year" /></td> 
                </tr> 
                
                <tr>
                <td>What For??</td> 
                    <td>
                        <select name="what"> 
                        <?php
                            $tag="SELECT tag_id,tag_description FROM tag";    //select query for tag
                            $GET_Item=mysql_query($tag);
                            while($result=mysql_fetch_assoc($GET_Item))  //building array
                            {
                            if($result['tag_id']==$tagID)           // condition statement
                            {                                                                                  
                            ?>
                            <option name="what" value="<?php echo $result['tag_id']; ?>"><?php echo $result['tag_description']; ?></option>      
                            <?php
                            }
                            else
                            {
                            ?>
                                <option name="what" value="<?php echo $result['tag_id']; ?>"><?php echo $result['tag_description']; ?></option>    
                            <?php
                            }  
                            }
                            ?>
                        </select>                     
                    </td>
                </tr>

                <tr>
                    <td colspan="2" align="center"><input type="submit" name="submit" value="submit"/></td>      
                </tr> 
                    
                       
            <table align="right">
            <tr>
        <td>
    </from>
        <?php
  $con=mysql_connect('localhost','root');                          // connection database
  mysql_selectdb('online_horoscope_system', $con);                 // selecting database
                                          
  if (isset($_POST['Balance']))
    $balance=$_POST['Balance'];
  else
    $balance="";
    ?>
        <?php
 if(isset($errors) && count($errors)>0){
        echo ("<b> The following errors occuried:</b><br />\n");
        echo ("<ul>\n");
        foreach ($errors as $error)
        {
            echo ("<li>".$error."</li>\n");
        }
    echo("</ul>\n"); 
    }
    ?>
        </td>    
            </tr>            
             </table> 
                                  
                
                 <?php          
                 if ($_POST['submit'] == ''){       //clicking button
                 echo '<div style="font-size:16px; color:orange; text-align:center;">Your current balance is ';                                                                        
            $un = $_SESSION['username'];
            $sql = "select  balance from customer where balance >(select  min(price) from astology) and customer_username='$un'";  
            $GET_bal=mysql_query($sql);                //count rows
            $result=mysql_fetch_row($GET_bal);         // building array
            if(!$result)
            $bal=0;
            else
            $bal=$result['0'];                                                                                   
            echo $bal.'.';
            echo '</div>'; 
            }          
            ?>
                
                

            
            
            
  
            <?php
            if ($_POST['submit'] == "submit") {         
                     
            
             
               //echo "<script> window.location = 'Realshow.php' </script>";       
               $conn = new PDO("mysql:host=localhost;dbname=online_horoscope_system",   //Geting connection   and calling Stored Procedure 
                      root);
                     //$sql = "call search_astology('$client_DOB','$ATag_id','$Adstats','$Amstats','$Aystats','$Acid')";
                     $sql = "call search_astology('$client_DOB','$ATag_id','$Adstats','$Amstats','$Aystats','$Acid')";
                     // $sql = "call search_astology('2014-1-1',1,1,0,0)";
                      $q = $conn->query($sql);
                      $q->setFetchMode(PDO::FETCH_ASSOC); 
                   
                    while($aa=$q->fetch())       //Call data by looping    
               {
             //echo'<div style="float:left; width:50px; height:50px; margin-top:200px; border-color:orange; border-style: solid;  border-width: 1px; float: left;"><img src="Image/'.$aa['image_id'] .'"></img></div>';                      
             //echo '<div style="width:100px; height:50px; text-align: center;  margin-top:200px; border-color:orange; border-style: solid;  border-width: 1px; float: left;"><img src="Image/f.jpg"></img></div>';                      

             echo '<div style="float:left; width: 99%; height:380px; margin-top:20px; border-style:solid; border_width:1px; border-color:blue; float:left;">
                  '.'<img style="width:150px; height:150px;" src="Image/'.$aa['image_id'] .'"></img><br />'.$aa['astology_description'] .'</div> ';                      
             
               }
             echo '</br>';
             
             echo '<div style="font-size:16px; color:orange; text-align:center;">Hello '.$name.'! This is your horoscope born on '.$dob.'. Your new balance is ';                                                                                                  
            $un = $_SESSION['username'];
            $sql = "select  balance from customer where customer_username='$un'";  
            $GET_bal=mysql_query($sql);          //counting rows
            $result=mysql_fetch_row($GET_bal);   //building array
            if(!$result)
            $bal=0;
            else
            $bal=$result['0'];                                                                                   
            echo $bal.'. </div>';                //output
              
            
            echo '<div><input type="button" value="Print" onclick="window.print()"></div>';                
                                    
            
            }
            ?>   
            
            
            
         </div>                                                                      
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> 

            <a class="menu" href="HelpCentre.php">Help</a>  
            
            <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>            
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div>                                             
        </div>
              </form>
    </body>
    <?php 
}
else{
    echo "<script>window.location='Home Page.php';</script>";
}
    
    ?>
    
    