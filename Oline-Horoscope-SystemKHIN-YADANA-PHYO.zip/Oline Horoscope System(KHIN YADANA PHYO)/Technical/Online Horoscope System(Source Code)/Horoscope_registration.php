<?php
      session_start();
if($_SESSION['admin_username'])
{
//session_start();
require_once('connection.php');
require_once('session.php');

?>
 
 <?php
  
  function GetHoroscopeByID($horoscope_id)
{
    $output = mysql_query("SELECT * FROM horoscope WHERE horoscope_id = '$horoscope_id'");
    $Horo = mysql_fetch_row($output);
    return $Horo;
}
       

function DeleteForHoroscope($horoscope_id)
{
    $Delete = "Call del_horoscope('$horoscope_id')";
    return mysql_query($Delete);
}

if (($_GET['action']) == 'delete' && !empty($_GET['id']))  
{
    DeleteForHoroscope($_GET['id']);
    echo "Deletion of that Horoscope is successful.";
}

$Horoscope = null;

if (($_GET['action']) == 'Edit' && !empty($_GET['id']))  
{
    $Horoscope =  GetHoroscopeByID($_GET['id']);
}


if (!is_null($Horoscope))
{
     $horoscope_id=$Horoscope[0];
   $horoscope_name  = $Horoscope[1];
   
}

else
{      $horoscope_id="";
    $horoscope_name = "";
 
}

?>
 
<html>
<head>
<title> Horoscope Registration </title>   
<script language="javascript" type="text/javascript">
function HoroscopelID_validation()
{
var HotelID = document.f.horoscope_id.value;

    if (horoscope_id == '')
    {
         document.getElementById("Horoscope_id_lable").innerHTML="Please Fill Horoscope ID";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("horoscope_id_lable").innerHTML="";
        //return true; 
    }
}

function HoroscopeName_validation()
{
var HotelName = document.f.horoscope_name.value;

    if (HoroscopeName == '')
    {
         document.getElementById("horoscope_name_lable").innerHTML="Please Fill Hotel Name";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("horoscope_name_lable").innerHTML="";
        //return true; 
    }
}


}  
</script>
</head>
 
<body >
  <table style="width:850px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header" style="margin-left:200px;">
        <img src="Image/banner.jpg" />
        </div>


        <div class="header1">
        <div class="HEADER" style="margin-left:200px;">  
        <a href="Report.php" class="linktab" target="frame">Home</a>     
        <a href="Logout.php" class="linktab" target="frame">LogOut</a> 
        </div>  
       
    <form action="edit and delete for horoscope_php.php" method="post" id="f" name="f"> 
    <table width="500px" height="400px" align="center" style="border-style:solid; border-color:lightpink;">
        <tr align="center">
        <td style="font-family:Comic Sans MS; color:olive;"> Horoscope ID </td>
        <td><input type="text" name="Horoscope_id" id="Horoscope_id"  onblur="HoroscopelID_validation" value="<?php echo  $horoscope_id; ?>"/> 
        <span id="CustomerID_lable"></span> </td>
        </tr>
    
        <tr align="center">
        <td style="font-family:Comic Sans MS; color:olive;"> Horoscope Name </td>
        <td><input type="text" name="horoscope_name" id="horoscope_name" onblur="HoroscopeName_validation()" value="<?php echo  $horoscope_name; ?>">
        <span id="CustomerName_lable"></span> </td>
        </tr>
        <tr>
             <td colspan="2" align="center"><input type="submit" value="Save">
        
        </tr>
    
    </table>
    </form>
</body>
</html>
<?php
       $a="SELECT  horoscope_id, horoscope_description
    from horoscope";
    
    $GET_Horoscope=mysql_query($a);


    echo '<table border=1 align="center" >';
  
        echo '<tr><th>Horoscope ID</th>';
        echo '<th>Horoscope Description</th>';
        echo '<th>Image</th>';

      echo '</tr>';
      while($aa=mysql_fetch_assoc($GET_Horoscope))
  {
      echo  '<tr>'; 
      echo '<td>'.$aa['horoscope_id'].'</td>' 
      . '<td>'.$aa['horoscope_description'].'</td>' 
        .'<td><img src="Images/'.$aa['ImageID'].'"></img></td>' ; 

      echo '<td>'.'<a href="Horoscope_Registration.php?action=Edit&id='.$aa['horoscope_id'].'
       &Name='.$aa['horoscope_name'].'">
      Edit</a>'.'</td>';
   echo '<td>'.'<a href="Horoscope_Registration.php?action=delete&id='.$aa['horoscope_id'].'">Delete</a>'.'</td>';
      echo '</tr>';
  }
       echo '</table>';
?>
      <?php 
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
   ?>   
  