<?
session_start();
include('connection.php');
//include('session.php');
function confirmUser($admin_username, $password)
{
    global $connection;
    //add slashes if necessary (for query)
    if(!get_magic_quotes_gpc())
        $admin_username    =addslashes($admin_username);;
    //verfify that user is in database
    $q    ="SELECT admin_password from admin where admin_username='$admin_username'";
    $result    =mysql_query($q,$connection);
    $a = mysql_num_rows($result);
    if(!$result || (mysql_numrows($result)<1))
        return 1; //indicate username failure
    //retrieve password from result, strip slashes
    $dbarray    =mysql_fetch_array($result);
    $dbarray['admin_password']    =stripslashes($dbarray['admin_password']);
    $password                =stripslashes($password);
        
    //validate that password is correct
    
    
    
    if($password== md5($dbarray['admin_password']))
        return '0'; //success , username name and password confirmed
    else 
        return "2"; // indicate password failure.
    
}
function checkLogin()
{
    //cheeck if user has been remembered
    /*
    if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookpass'])) 
    {
        $_SESSION['admin_username']=$_COOKIE['cookname'];
        $_SESSION['admin_password']=$_COOKIE['cookpass'];
    }
    */
    //username and password has been set
    if(isset($_SESSION['admin_username']) && isset($_SESSION['admin_password']))
    {
        //confirm that username and password  are valid
        if(confirmUser($_SESSION['admin_username'],$_SESSION['admin_password'])!=0)
        {
            //variables are incorrect, user not logged in
            unset($_SESSION['admin_username']);
            unset($_SESSION['admin_password']);
            return false;
        }
        return true;
    }
    else return false;
}
    ?>
    <?php
function displayLogin()
{
    global $logged_in;
    if($logged_in)
    {
        //echo "<h1>Logged In</h1>";
        //echo "Welcome <b>".$_SESSION['username']."</b> you are logged in.<a href=\"logout.php\">Logout</a>";
        echo "<script> window.location = 'Report.php' </script>";
    }
    else
    {
    ?>
<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>
    <form method="post">
    <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D" > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
<? include('Menu.php')?>
        
        <!--Body-->
        <div class="body">
           <table style="margin-top:20px;" align="center" class="rpt" width="20px">              
                <tr>
                    <td><img style="width:100px; height:100px;" src="Image/logo.gif"/></td>
                 </tr>  
               
                <tr>
                    <td class="rpt">User Name:</td>
                    <td><input type="text" id="admin_username" name="admin_username" maxlength="30" /></td>                     
                </tr>                                    
                <tr>
                    <td class="rpt">Password:</td>
                    <td><input type="password" id="admin_password" name="admin_password" maxlength="30"/></td> 
                </tr> 
                <tr>
                <td colspan="2" align="left">
                    <input type="checkbox" name="remember">
                    <font size="2">Remember me next time</font>
                </td>
                </tr>
                <tr>
                    <td ></td>
                    <td ></td>  
                    <td><input type="submit" name="sublogin" value="GO!"/> </td>                  

                                                
            </table> 
         </div>      
             
            
        <!--Footer-->
        
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |

            <a class="menu" href="HelpCentre.php">Help</a>  
            <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div>
        </div>

    </body>
    </form>
</html>
    
    <?
    }
}    
if(isset($_POST['sublogin']))
{
    //check that all fields were typed in
    if(!$_POST['admin_username'] || !$_POST['admin_password'])
    {
        die('You didn\'t fill in a required field.');
    }
    //spruce up username,check length
    $_POST['admin_username']=trim($_POST['admin_username']);
    if(strlen($_POST['admin_username'])>30)
    {
        die("sorry, the usename is longer than 30 characters");
    }
    //check username is in database and password is correct
    $md5pass    =md5($_POST['admin_password']);
    
    $result        =confirmUser($_POST['admin_username'],$md5pass);
    //check error code
    if($result ==1)
    die('That username doesn\'t exist in our database');
    else if($result==2)
    die('Incorrec password, please try again');
    //username and password correct, registersession variables
    //$_POST['admin_username']    =stripslashes($_POST['user']);
    if($_POST['admin_username']){
        $admin_username = stripslashes($_POST['admin_username']);
    }
    $_SESSION['admin_username']=$_POST['admin_username'];
    $_SESSION['admin_password']=$md5pass;
    
    if(isset($_POST['remember']))
    {
        setcookie("cookname",$_SESSION['admin_username'],time()+60*60*24*100);
        setcookie("cookpass",$_SESSION['admin_password'],time()+60*60*24*100);
    }
    //quick self-redirect to avoid resending data on refresh
    echo "<meta http-equiv=\"Refresh\" content=\"0;url=$HTTP_SERVER_VARS[PHP_SELF]\">";
    return;
}
//set the value of the logged_in variable , which can be used im your code
$logged_in=checkLogin();
?>
<? displayLogin(); ?>