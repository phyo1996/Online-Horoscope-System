<?php
session_start();        
if($_SESSION['admin_username'])
{    
  require_once("connection.php");
  require_once("session.php"); 
  //require_once("AutoID.php");
  
  function GetprepaidcardByID($prepaidcard_id)
{
    $output = mysql_query("SELECT * FROM prepaid_card WHERE prepaidcard_id ='$prepaidcard_id'");
    $Horo = mysql_fetch_row($output);
    return $Horo;
}
       

function DeleteForPrepaid_card($prepaidcard_id)
{
    $Delete = "Call del_prepaid_card('$prepaidcard_id')";
    return mysql_query($Delete);
}

if (($_GET['action']) == 'delete' && !empty($_GET['id']))  
{
    DeleteForPrepaid_card($_GET['id']);
    echo "Deletion of that Preapid card is successful.";
}

$prepaidcard_card = null;

if (($_GET['action']) == 'Edit' && !empty($_GET['id']))  
{
    $prepaidcard_card =  GetprepaidcardByID($_GET['id']);
}


if (!is_null($prepaidcard_card))
{
     $prepaidcard_id=$prepaidcard_card[0];
$prepaidcard_amount=$prepaidcard_card[1];
$preapaidcard_currency=$prepaidcard_card[2];
$prepaidcard_expired_date=$prepaidcard_card[3];
}

else
{     
     $prepaidcard_id="";
     $prepaidcard_amount="";
     $preapaidcard_currency="";
     $preapaidcard_expired_date="";


 
}

?>
 
<html>
<head>
<title> Prepaid_card Registration </title>   
<script language="javascript" type="text/javascript">
function HoroscopelID_validation()
{
var Prepaid_card_id = document.f.prepaidcard_id.value;

    if (prepaidcard_id == '')
    {
         document.getElementById("$prepaidcard_card_id_lable").innerHTML="Please Fill preapid_card ID";
         //alert('Fill Prepaid_card_id');
         //return false; 
    }
    else
    {   
        document.getElementById("$prepaidcard_card_id_lable").innerHTML="";
        //return true; 
    }
}

function prepaidcard_card_id_validation()
{
var prepaidcard_amount = document.f.prepaidcard_amount.value;

    if (prepaidcard_amount == '')
    {
         document.getElementById("prepaidcard_card_amount_lable").innerHTML="Please Fill preapaid card amount";
         //alert('Fill Prepaid_card_id');
         //return false; 
    }
    else
    {   
        document.getElementById("prepaidcard_card_amount_lable").innerHTML="";
        //return true; 
    }
}

function prepaidcard_currency_validation()
{
var prepaidcard_currency = document.f.prepaidcard_currency.value;

    if (prepaidcard_currency == '')
    {
         document.getElementById("prepaidcard_card_currency_lable").innerHTML="Please Fill preapaid card currency";
         //alert('Fill Prepaid_card_id');
         //return false; 
    }
    else
    {   
        document.getElementById("prepaidcard_card_currency_lable").innerHTML="";
        //return true; 
    }
}

function prepaidcard_expired_date_validation()
{
var prepaidcard_expired_date = document.f.prepaidcard_expired_date.value;

    if (prepaidcard_expired_date == '')
    {
         document.getElementById("prepaidcard_card_expired_date_lable").innerHTML="Please Fill preapaid card expired date";
         //alert('Fill Prepaid_card_id');
         //return false; 
    }
    else
    {   
        document.getElementById("prepaidcard_card_expired_date_lable").innerHTML="";
        //return true; 
    }
}



}  
</script>
</head>
 
<body bgcolor="white">
  <table style="width:850px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header" style="margin-left:200px;">
        <img src="Image/banner.jpg" />
        </div>


        <div class="header1">
        <div class="HEADER" style="margin-left:200px;">  
        <a href="Report.php" class="linktab" target="frame">Home</a>     
        <a href="logout.php" class="linktab" target="frame">LogOut</a> 
        </div>  
       
    <form action="editanddeleteprepaidcard.php" method="post" id="f" name="f"> 
    <table width="500px" height="400px" align="center" style="border-style:solid; border-color:lightpink;">           
        <tr align="center">
        <td> Prepaid_card ID </td>
        <td><input type="text" name="prepaidcard_id" id="prepaidcard_id" onblur="prepaidcard_card_id_validation" value="<?php echo $prepaidcard_id; ?>"/> 
        <span id="prepaidcard_card_id_lable"></span> </td>
        </tr>
    
        <tr align="center">
        <td> Prepaid_card Amount </td>
        <td><input type="text" name="prepaidcard_amount" id="prepaidcard_amount" onblur="preapid_card_amount_validation()" value="<?php echo  $prepaidcard_amount; ?>">
        <span id="prepaidcard_card_amount_lable"></span> </td>
        </tr>
        
        <tr>
         <tr align="center">
        <td> Prepaid_card Currency </td>
        <td><input type="text" name="prepaidcard_currency" id="prepaidcard_currency" onblur="prepaidcard_currency_validation()" value="<?php echo  $preapaidcard_currency; ?>">
        <span id="prepaidcard_card_currency_lable"></span> </td>
        </tr>
        <tr>
        
        <tr>
         <tr align="center">
        <td> Prepaid_card Expired Date </td>
        <td><input type="text" name="prepaidcard_expired_date" id="prepaidcard_expired_date" onblur="prepaidcard_expired_date_validation()" value="<?php echo  $prepaidcard_expired_date; ?>">
        <span id="prepaidcard_card_expired_date_lable"></span> </td>
        </tr>
        <tr>
        
             <td colspan="2"><input type="submit" value="Save">
        
        </tr>
    
    </table>
    </form>
</body>
</html>
<?php
       $a="SELECT  prepaidcard_id, prepaidcard_amount,prepaidcard_currency,prepaidcard_expired_date,prepaidcard_status
    from prepaid_card;";
    
    $GET_Prepaid_card=mysql_query($a);


    echo '<table border=1 align="center" >';
                                                                        
        echo '<tr><th>Prepaid ID</th>';
        echo '<th>Preapid amount</th>';
        echo '<th>Preapid currency</th>';
        echo '<th>Preapid expired_date</th>';
        echo '<th>Prepaid status</th>';

      echo '</tr>';
      while($aa=mysql_fetch_assoc($GET_Prepaid_card))
  {
      echo  '<tr>'; 
      echo '<td>'.$aa['prepaidcard_id'].'</td>' 
      . '<td>'.$aa['prepaidcard_amount'].'</td>' 
      .'<td>'.$aa['prepaidcard_currency'].'</td>'
      .'<td>'.$aa['prepaidcard_expired_date'].'</td>'
      .'<td>'.$aa['prepaidcard_status'].'</td>';

      echo '<td>'.'<a href="prepaidcard_registration.php?action=Edit&id='.stripslashes($aa['prepaidcard_id']).'
       &Amount='.$aa['prepaidcard_amount'].'$currency='.$aa['prepaidcard_currency'].'$expired_date='.$aa['prepaidcard_expired_date'].'$status='.$aa['prepaidcard_status'].'">
      Edit</a>'.'</td>';
   echo '<td>'.'<a href="prepaidcard_registration.php?action=delete&id='.$aa['prepaidcard_id'].'">Delete</a>'.'</td>';
      echo '</tr>';
  }
       echo '</table>';
?>
      <?php 
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
    ?>