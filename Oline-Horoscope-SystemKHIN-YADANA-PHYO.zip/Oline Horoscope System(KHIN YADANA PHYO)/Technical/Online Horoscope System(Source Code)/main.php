<?php
session_start();
include("connection.php");
include("login.php");
?>
<html>
<head>
	<title>Login Example</title>
</head>
<body>
	<? displayLogin();?>
</body>
</html>