<?php

  require_once("connection.php");
  $con=mysql_connect('localhost','root');
  mysql_selectdb('online_horoscope_system', $con);
  function GetHoroscopeByID($horoscope_id)
{
    $output = mysql_query("SELECT * FROM horoscope WHERE horoscope_id = '$horoscope_id'");
    $Horo = mysql_fetch_row($output);
    return $Horo;
}
                                          
  if (isset($_POST['Horoscope_id']))
    $horoscopeid=$_POST['Horoscope_id'];
  else
    $horoscopeid="";
  
  if (isset($_POST['horoscope_name']))
   $horoscopedescriptionn=$_POST['horoscope_name'];
  else
    $horoscopedescriptionn="";
  
echo "$horoscopeid";
$Horoscope = GetHoroscopeByID($horoscopeid);
echo $Horoscope;

if ($Horoscope)
{
           echo "Horoscope information exists!";
  $sql = "call Upd_horoscope('$horoscopeid','$horoscopedescriptionn')";  
  if (mysql_query($sql))
  {
      $message = 'Horoscope updated successfully';
  }
  else
  {
      $message = mysql_error();
  }
}
else
{
          echo "No existing horoscope information";  
$sql = "call Ins_horoscope('$horoscopedescriptionn','$ImageID')";    
    
      $r = mysql_query($sql);
                                                
if(!$r)
{
        $message = mysql_error();
}
else
{
    //header("location: Hotel_Information.php");
    $message = "New horoscope is successfully saved!";    
}

}
?>

<h3><?php
//echo "[$sql]";
    echo $message;
?></h3>
<a href="Horoscope_registration.php">View</a>
