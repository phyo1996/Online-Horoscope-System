<?php
    session_start();
    require_once("session.php");
?>

<html>
    <head>
       <link rel="stylesheet" type="text/css" href="CSS/Test.css" />        
    <!--   <script language="javascript" type="text/javascript">

           
function CustomerName_validation()
    {
    var CustomerName = document.CustomerForm.CustomerName.value.length;
   // alert('aaaa');
        if (CustomerName == 0 || CustomerName < 6)
             document.getElementById("CustomerName_lable").innerHTML="Please Insert Username";
        else
            document.getElementById("CustomerName_lable").innerHTML="";
    }

function Password_validation()
    {
    var Password = document.CustomerForm.CustomerPassword.value.length;
        if (Password == 0 || Password < 7)
             document.getElementById("Password_lable").innerHTML="Password atleast 8 characters";
        else
            document.getElementById("Password_lable").innerHTML="";
    }
    
function RetryPW_validation()
    {
    var Password = document.CustomerForm.CustomerPassword.value;
    var Retry_PW = document.CustomerForm.RetryPW.value;

        if (Password != Retry_PW )
            document.getElementById("RetryPW_lable").innerHTML="Do not match";
        else
            document.getElementById("RetryPW_lable").innerHTML="";
    }
    
function CustomerEmail_validation()
    {
        var Email = document.CustomerForm.CustomerEmail.value;
            if (Email == '')
            {
                document.getElementById("CustomerEmail_lable").innerHTML="Please insert Email";}
            else
            {
                document.getElementById("CustomerEmail_lable").innerHTML="";
    }        }

function CustomerNRC_validation()
    {
    var NRC = document.CustomerForm.NRC.value;
        if (NRC == '')
             document.getElementById("CustomerNRC_lable").innerHTML="Please insert Current Address";
        else
            document.getElementById("CustomerNRC_lable").innerHTML="";
    }
    
function Customer_Address validation()
    {
    var CAddress = document.CustomerForm.CustomerAddress.value;
        if (CAddress == '')
             document.getElementById("CustomerAddress_lable").innerHTML="Please Insert Customer Address";
        else
            document.getElementById("CustomerAddress_lable").innerHTML="";
    }
function Clear()
    {
        document.CustomerForm.CustomerID.value = "";
        document.CustomerForm.customername.value = "";
        document.CustomerForm.customerpassword.value = "";
        document.CustomerForm.CreatePassword.value = "";
        document.CustomerForm.customeremail.value = "";
        document.CustomerForm.address.value = "";
        document.CustomerForm.nrc.value = "";
    }
</script>  -->       
     </head> 
           
     <script language="javascript" type="text/javascript">
function CustomerName_validation()
{
var C_name = document.f.CustomerName.value;

    if (C_name == '' || C_name < 6)
    {
         document.getElementById("CustomerName_lable").innerHTML="Please Fill Horoscope ID";
    }
    else
    {   
        document.getElementById("CustomerName_lable").innerHTML="";
        //return true; 
    }
}
</script>

<?php
 require_once("connection.php");      //call connection

  if(isset($_POST['CustomerName']))
  $Customer_Name=$_POST['CustomerName'];
  else                                           
  $Customer_Name="";
  if(isset($_POST['start_date']))
  $start_date=$_POST['start_date'];
  else
  $start_date="";
  
  
  if(isset($_POST['CustomerEmail']))
  $Customer_Email=$_POST['CustomerEmail'];
  else
  $Customer_Email="";
  
    if(isset($_POST['gender']))
  $Gender=$_POST['gender'];
  else
  $Gender="";
                                                        
  if(isset($_POST['country']))
  $Country=$_POST['country'];
  else
  $Country="";
     if(isset($_POST['username']))
  $username=$_POST['username'];
  else
  $Customer_Password="";
  if(isset($_POST['CustomerPassword']))
  $Customer_Password=$_POST['CustomerPassword'];
  else
  $Customer_Password="";
  

  
  if(isset($_POST['NRC']))
  $nrc=$_POST['NRC'];
  else
  $nrc="";
  
  if(isset($_POST['CustomerAddress']))
  $Customer_Address=$_POST['CustomerAddress'];
  else
  $Customer_Address="";
  
  $todaydate=date('Y-m-d');
  If (isset($_POST[submit])  )
  {
   $INS="Call Ins_customer('$Customer_Name','$start_date','$username','$Customer_Password','$todaydate','$gender','$Country','$nrc','$Customer_Address',0,'$Customer_Email')";
    
     if(!mysql_query($INS))               // counting rows
      echo mysql_error()."<br>";        //ouput error
 
  else
  echo "<h1>"."SuccessFul for  <?php echo $_SESSION[username]; ?> "."</h1>";
  }

?>

    <body style="text-align:center">

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>                                                              
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->

        <?php
            include('Menu.php');
        ?>
        
        <form action="" method="post" id="CustomerForm" name="CustomerForm">                         
        
        <!--Body-->
        <div class="body" style="height:580px">
            <table cellpadding="12" cellspacing="1" border="0" align="center" class="Param" style="height:245px"> 
            <tr style="font-size: 30px" align="center"> Registration Form </tr>

            <tr >
                <td width="170px" style="font-family:Comic Sans MS">Customer Name:</td>
                <td width="100px"> <input type="text" name="CustomerName" id="CustomerName" onblur="CustomerName_validation()" value="<?php echo  $customer_name; ?>"/></td>
                <td width="200px"> <span id="CustomerName_lable"></span>       </td>     
            </tr>
            
            <tr>
                <td style="font-family:Comic Sans MS">Customer Email:</td>
                <td> <input type="pass" name="CustomerEmail" id="CustomerEmail" onblur="CustomerEmail_validation()" /></td>
                <td>  <span id="CustomerEmail_lable"></span>       </td>     
            </tr>

            <tr>
                <td style="font-family:Comic Sans MS"> Gender  </td>
                <td>   <input type="radio" name="gender" id="male" value="1" >Male </br> 
                <input type="radio" name="gender" id="female" value="0" >Female   </td>
                <td>  <span id="Cname_lable"></span>       </td>     
            </tr>
        <!--   <tr>
                <td style="font-family:Comic Sans MS">Date Of Birth :</td>
                <td><input type="text" value="1 Jan 2014" disabled="True"/> <img src="image/iconCalendar.gif">
                </td>
                <td>  <span id="Cname_lable"></span>       </td>                                              
            </tr> -->
                      <tr>
                    <td style="font-family:Comic Sans MS">Date of Birth:</td>
                    <td>
                      
                        <input name="start_date" type="text" id="datepicker" >
              
                    </td>                           
                    <td></td>
                    <td></td>
                </tr>
                <tr>
            <tr>
                <td style="font-family:Comic Sans MS">Country</td>
            <td>    <select name="country" value="day">
                        <option value="Amercia">Amercia</option> 
                        <option value="British">British</option> 
                        <option value="Canada">Canada</option> 
                        <option value="Myanmar">Myanmar</option>
                        <option value="USA">USA</option>    
                    </select>
            </td>
            <td>  <span id="Cname_lable"></span>       </td>                                              
            </tr>
                                <tr>
                <td style="font-family:Comic Sans MS">UserName:</td>
                <td> <input type="pass" name="username" id="username" onblur="" /></td>
                <td>  <span id=""></span>       </td>     
            </tr>
            <tr>
                <td style="font-family:Comic Sans MS">Customer Password:</td>
                <td> <input type="pass" name="CustomerPassword" id="CustomerPassword" onblur="Password_validation()" /></td>
                <td>  <span id="Password_lable"></span></td>     
            </tr>
            
            <tr>
                <td style="font-family:Comic Sans MS">Customer Confiirmation Password</td>
                <td><input type="text" name="RetryPW" id="RetryPW" onblur="RetryPW_validation()" /></td>
                <td>  <span id="RetryPW_lable"></span>       </td>                                              
            </tr>

            <tr>
                <td style="font-family:Comic Sans MS">Customer NRC</td>
                <td><input type="text" name="NRC" id="NRC" onblur="CustomerNRC_validation()" /></td>
                <td>  <span id="CustomerNRC_lable"></span></td>                                              
            </tr>

            <tr>
                <td style="font-family:Comic Sans MS">Customer Adddress</td>
                <td><input type="text" name="CustomerAddress" id="CustomerAddress" /></td>
                <td>  <span id="CustomerAddress_lable"></span>       </td>                                              
            </tr>
            <tr>
                <td colspan="3" align="center" valign="middle"> <input type="submit" id="submit" name="submit" value="Let go register" /></td>
            </tr>
            </table>   
         </div>  
 <meta charset="utf-8">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\themes\base\jquery-ui.css">
  <script src="\\jquery-ui-1.10.4\jquery-1.10.2.js"></script>
  <script src="\\jquery-ui-1.10.4\ui/jquery-ui.js"></script>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\demos\demos.css">
  <script>
  $(function() {
    $( "#datepicker" ).datepicker({dateFormat: 'yy-mm-dd'});
  });
  </script> 
         </form>

             
<?php
    if (isset ($_POST['submit']))   //clicking button
    {
       // $error = Array();
        if ($_POST['customername']<'6' )
        {
            
             //$errors[]='Your Name is too short & Please type again';
           //  window.alert($error[]);
   ?>      
          
                <?php
    

        } 
        
     
            else if ($_POST['customerpassword']<'6' )
        {
           // $errors[]='Your Password is too short & Plaease type again';
        //    window.alert($error[]);
        //alert("sent");
   ?>       
                <?php
        } 
       else  if ($_POST['pass']!= $_POST['customerpassword'] )
        {
            //$errors[]='Password do not match';
      //      window.alert($error[]);
   ?>      
         <p style="height: 50px;">
                    <!--<span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 50px 0;"></span>-->
                    <span style="background-image: url('warning.png'); width: 48px; height: 48px; float: left; margin:0 7px 10px 0;"></span>
                    
         </p> 
                <?php
        }  
        else if (!preg_match('/^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,4}$/i',$_POST['customeremail']) )
        {
           // $errors[]=      echo"<script> alert(Password do not match');</script>";';
   ?>      
         <p style="height: 50px;">
                    <span style="background-image: url('warning.png'); width: 48px; height: 48px; float: left; margin:0 7px 10px 0;"></span>
                    This is test message.
         </p> 
         
                <?php
        } 
        } 
        ?> 
        
<?php
 /* if(isset($errors) && count($errors)>0){
        echo ("<b> The following errors occuried:</b><br />\n");
        echo ("<ul>\n");
        foreach ($errors as $error)
        {
            echo ("<li>".$error."</li>\n");
        }
    echo("</ul>\n"); 
    }
*/    
?>                                                            
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
          
            <a class="menu" href="HelpCentre.php">Help</a>  
            <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div> 
    </body>
</html>