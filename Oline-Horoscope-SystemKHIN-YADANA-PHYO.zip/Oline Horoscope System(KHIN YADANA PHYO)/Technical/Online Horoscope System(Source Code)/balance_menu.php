<?php
    session_start();     
    if($_SESSION['username'])
{
    require_once("connection.php");   //call connection
    require_once("session.php");

?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>
    <form method="post">

    <body style="text-align:center">

          <table style="width:850px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
        <? include('Menu.php'); ?>
        
        
        <!--Body-->
        <div class="body" >
        </br></br></br></br>
          <?php          
                 if ($_POST['submit'] == ''){       //clicking button
                 echo '<div style="font-size:24px; color:orange; text-align:center;">Your current balance is ';                                                                        
            $un = $_SESSION['username'];
            $sql = "select  balance from customer where balance >(select  min(price) from astology) and customer_username='$un'";  
            $GET_bal=mysql_query($sql);                //count rows
            $result=mysql_fetch_row($GET_bal);         // building array
            if(!$result)
            $bal=0;
            else
            $bal=$result['0'];                                                                                   
            echo $bal.'.';
            echo '</div>'; 
            }          
            ?>
          
                 </form>
                </div>                                                                      
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |

            <a class="menu" href="HelpCentre.php">Help</a>  
        <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div>
        </div>
      
    </body>
</html>


<?php 
}
else{
    echo "<script>window.location='Home Page.php';</script>";
}
    