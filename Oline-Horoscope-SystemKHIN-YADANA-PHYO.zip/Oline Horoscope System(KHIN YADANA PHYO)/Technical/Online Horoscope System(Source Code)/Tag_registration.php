<?php
          session_start();
if($_SESSION['admin_username'])
{      
    session_start();    
  require_once("connection.php");
  require_once("session.php"); 
  //require_once("AutoID.php");
  

 function tag($tag_id)
 {
 $output = mysql_query ("SELECT * FROM tag WHERE tag_id = '$tag_id'");
 $Horo  = mysql_fetch_row($output);
 return $Horo;
 }
       

function DeleteForTag($tag_id)
{
    $Delete = "Call del_tag('$tag_id')";
    return mysql_query($Delete);
}

if (($_GET['action']) == 'delete' && !empty($_GET['id']))  
{
    DeleteForTag($_GET['id']);
    echo "Deletion of that tag is successful.";
}

$Horoscope = null;

if (($_GET['action']) == 'Edit' && !empty($_GET['id']))  
{
    $Horoscope =  tag($_GET['id']);
}

if (!is_null($Horoscope))
{
   $tag_id = $Horoscope[0];
   $tag_description = $Horoscope[1];
}
else
{
     $tag_id = ""; 
   $tag_description  = "";   
}

?>

 
 <html>
<head>
<title> Tag Registration </title>   
<script language="javascript" type="text/javascript">
function Tag_validation()
{
var horoscope_id = document.f.tag_id.value;

    if (horoscope_id == '')
    {
         document.getElementById("tag_id_lable").innerHTML="Please Fill Horoscope ID";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("tag_id_lable").innerHTML="";
        //return true; 
    }
}

function Tag_description_validation()
{
var tag_description = document.f.tag_description.value;
                                    
    if (tag_description == '')
    {
         document.getElementById("Tag_description_lable").innerHTML="Please Fill Tag Description";
         //alert('Fill HotelID');
         //return false; 
    }
    else
    {   
        document.getElementById("Tag_description_lable").innerHTML="";
        //return true; 
    }



}  
</script>
</head>
 
<body bgcolor="white">
  <table style="width:850px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header" style="margin-left:200px;">
        <img src="Image/banner.jpg" />
        </div>

<form action="edit and delete for tag.php" method="post" id="f" name="f"> 
    
        <div class="header1" >
        <div class="HEADER" style="margin-left:200px;">  
        <a href="Report.php" class="linktab"  target="frame">Home</a>     
        <a href="logout.php" class="linktab" target="frame">LogOut</a> 
        </div>  
       
    <table width="500px" height="400px" align="center" style="border-style:solid; border-color:lightpink;">
        <tr align="center"  >
        <td style="font-family:Comic Sans MS; color:olive;"> Tag ID </td>                     
        <td><input type="text" name="ttag_id" id="ttag_id" onblur="Tag_validation()" value="<?php echo  $tag_id; ?>"> 
        <span id="tag_id_lable"></span> </td>  
        </tr>
    
        <tr align="center">
        <td style="font-family:Comic Sans MS; color:olive;"> Tag Description </td>
        <td><input type="text" name="tag_description" id="tag_description" onblur="Tag_description_validation()" value="<?php echo  $tag_description; ?>">
        <span id="Tag_description_lable"></span> </td>
        </tr>
        <tr>
             <td colspan="2" style="text-align:center;" ><input type="submit" value="Save" name="Save" id="Save" style="text-align:center;"></td>
        
        </tr>
    

 
        <?php
       $a="SELECT  tag_id, tag_description
    from tag";
    
    $GET_tag=mysql_query($a);

  echo '<table border=1 align="center">';
        echo '<tr><th>Tag ID</th>';
        echo '<th>Tag Description</th>';
        echo '</tr>';
      while($aa=mysql_fetch_assoc($GET_tag))
  {
      echo  '<tr>'; 
      echo '<td>'.$aa['tag_id'].'</td>'
      . '<td>'.$aa['tag_description'].'</td>' ;

        echo '<td>'.'<a href="Tag_Registration.php?action=Edit&id='.$aa['tag_id'].'">
      Edit</a>'.'</td>';
   echo '<td>'.'<a href="Tag_Registration.php?action=delete&id='.$aa['tag_id'].'">Delete</a>'.'</td>';
      echo '</tr>';
  }
       echo '</table>';
 ?> </td>  
       </tr>
       
</table>
</form>
</body> 
</html>
            <?php
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
    ?>