<?php
session_start();
include('connection.php');
include('login.php');
if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookpass']))
{
    setcookie("cookname","",time()-60*60*24*100);
    setcookie("cookpass","",time()-60*60*24*100);
}
?>
<html>
    <head><title>Logging Out</title></head>
    <body>
        <?
        if(!$logged_in)
        {
            /*echo "<h1>Error!</h1>\n";
            echo "You are not currently logged in, logout failed.Back to "*/ ?> <!--<a href="main.php" >main</a>  -->
            echo "<script> window.location = 'Home Page.php' </script>"; 
        <?php    
        }
        else
        {
            //kill session variables
            unset($_SESSION['username']);
            unset($_SESSION['admin_username']);                
            unset($_SESSION['adminid']);
            unset($_SESSION['password']);
            unset($_SESSION['admin_password']);
            $_SESSION[]=array();     //reset session array
            session_destroy();    //destroy session
            /*
            echo "<h1>Logged Out</h1>\n";
            echo "Your have successfully logged out.Back to " */?> <!--<a href="main.php" >main</a>-->
            echo "<script> window.location = 'Home Page.php' </script>"; 
            <?php
        }
        ?>
        
        <?php
session_start();
include('connection.php');
include('staff_login.php');
if(isset($_COOKIE['cookname']) && isset($_COOKIE['cookpass']))
{
    setcookie("cookname","",time()-60*60*24*100);
    setcookie("cookpass","",time()-60*60*24*100);
}
?>
<html>
    <head><title>Logging Out</title></head>
    <body>
        <?
        if(!$logged_in)
        {
            /*echo "<h1>Error!</h1>\n";
            echo "You are not currently logged in, logout failed.Back to "*/ ?> <!--<a href="main.php" >main</a>  -->
            echo "<script> window.location = 'Home Page.php' </script>"; 
        <?php    
        }
        else
        {
            //kill session variables
            unset($_SESSION['username']);
            unset($_SESSION['password']);                                
            unset($_SESSION['adminid']);
            unset($_SESSION['admin_username']);
            unset($_SESSION['admin_password']);
            $_SESSION[]=array();     //reset session array
            session_destroy();    //destroy session
            /*
            echo "<h1>Logged Out</h1>\n";
            echo "Your have successfully logged out.Back to " */?> <!--<a href="main.php" >main</a>-->
            echo "<script> window.location = 'Home Page.php' </script>"; 
            <?php
        }
        ?>
    </body>
</html>