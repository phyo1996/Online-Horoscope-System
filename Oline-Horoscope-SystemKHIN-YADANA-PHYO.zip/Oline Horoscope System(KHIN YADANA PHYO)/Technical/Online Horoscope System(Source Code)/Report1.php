<?php
      session_start();    // starting session 
if($_SESSION['admin_username'])
{
               
require_once('session.php'); // call session    
       ?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />   
              
  <meta charset="utf-8">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\themes\base\jquery-ui.css">
  <script src="\\jquery-ui-1.10.4\jquery-1.10.2.js"></script>
  <script src="\\jquery-ui-1.10.4\ui/jquery-ui.js"></script>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\demos\demos.css">
  <script>
  $(function() {
    $( "#datepicker" ).datepicker({dateFormat: 'yy-mm-dd'});
  });
  </script>
  <script>
  $(function() {
    $( "#datepickerend" ).datepicker({dateFormat: 'yy-mm-dd'});
  });
  </script>
    </head>
         
    <body style="text-align:center">
<form name="BS" id="BS" action="" method="post"> 

        <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php');?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
                <!--Menu-->
        <?php
            include('Menu.php');
        ?>
 
        <!--Body-->
        <div class="body">
                <table align="center" class="param">
                <tr>
                    <td>Start Date:</td>
                    <td>
                      
                        <input name="start_date" type="text" id="datepicker" >
              
                    </td>                           
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>End Date:</td>
                    <td>
                      
                        <input name="end_date" type="text" id="datepickerend" >
              
                    </td>                           
                    <td><input type="submit" name="view" value="View"/></td>
                    <td></td>
                </tr>
            </table>            
         <!--  <table align="center" class="rpt">              
                <tr>
                    <td><img style="width:100px; height:100px;" src="Image/logo.gif"/></td>
                    <td colspan="3"><b><u>Newly Member Registration Report for the Month of December</u></b></td>   
                </tr>
                <tr style="text-align:right;">
                    <td colspan="5">Report Date: 31/december/2013</td>                       
                </tr> 
                <tr>
                    <td class="rpt">Member ID</td>
                    <td class="rpt">Member Name</td>
                    <td class="rpt">Gender</td>
                    <td class="rpt">Address</td>                     
                    <td class="rpt">Register Date</td>
                </tr>                                    
                <tr>
                    <td class="rptData">M0001</td>
                    <td class="rptData">Mary</td>                     
                    <td class="rptData">Female</td>
                    <td class="rptData">US</td>
                    <td class="rptData">5 Dec 2013</td>
                </tr>
                <tr>
                    <td class="rptData">M0002</td>
                    <td class="rptData">Steven</td>                     
                    <td class="rptData">Male</td>
                    <td class="rptData">Britain</td>
                    <td class="rptData">6 Dec 2011</td>
                </tr> 
                <tr>
                    <td class="rptData">M0003</td>
                    <td class="rptData">Smith</td>                     
                    <td class="rptData">Male</td>
                    <td class="rptData">China</td>
                    <td class="rptData">16 Dec 2011</td>                    
                </tr>
                <tr>
                    <td class="rptData">M0004</td>
                    <td class="rptData">Roger</td>                     
                    <td class="rptData">Male</td>
                    <td class="rptData">India</td>
                    <td class="rptData">18 Dec 2011</td>                    
                </tr>
                <tr>
                    <td colspan="3" class="rpt">Total Number Of Members :</td>
                    <td colspan="2" class="rpt">4</td>
                </tr>                 
                <tr>
                    <td></td>
                    <td></td>
                </tr>                                   
            </table> -->
            <?php
       
 if ($_POST['view'] == "View")            //Clicking search button 
 {       
     if(isset($_POST['start_date']))      //Geting data
        $s_date = $_POST['start_date'];
         else
        $s_date="";
        if(isset($_POST['end_date']))
         $e_date=$_POST['end_date'];
        else
        $e_date="";
     
       $conn = new PDO("mysql:host=localhost;dbname=online_horoscope_system",'root' );    //Geting connection   and calling Stored Procedure 
        $sql="Call Rpt_member('$s_date','$e_date')";
        $q = $conn->query($sql);
        $q->setFetchMode(PDO::FETCH_ASSOC); 

                                                                                                                              
                                                               
    echo '<table align="center" class="rpt">';
        echo '<tr>';
                echo '<td><img style="width:100px; height:100px;" src="Image/logo.gif"/></td>';
                echo '<td colspan="3"><b><u>Newly Member Registration Report</u></b></td>';   
       echo '</tr>';
        
        echo '<tr>';                    //Giving table header
        echo '<th class="rpt"> Member ID </th>'  
            .'<th class="rpt"> Member Name </th>'
            .'<th class="rpt"> Register Date </th>';         
        echo '</tr>';

  
           
      while($r=$q->fetch())             //Call data by looping  
  {        
        echo  '<tr>'; 
      echo '<td class="rpt">'.$r['customer_id'].'</td>' 
          .'<td class="rpt">'.$r['customer_name'].'</td>'
          .'<td class="rpt">'.$r['RegisterDate'].'</td>';   
      echo '</tr>';

  }
        
      
       echo '</table>';
                                                    
 }
 
?>
            
         </div>                                                                      
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
             
            <a class="menu" href="Help.php">Help</a>  
            <br/>
        � KYDNP
        </div>
        
        </form>
    </body>
</html>
<?php
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
    ?>