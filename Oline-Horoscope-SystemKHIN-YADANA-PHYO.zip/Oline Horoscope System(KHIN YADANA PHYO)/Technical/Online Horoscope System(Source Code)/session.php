<?php
  session_start();
  if (!isset($_SESSION['username'])){
      //header('location:Login.php');   
      //echo "<script> window.location = 'Home Page.php' </script>";
  }
  else {
      $username=$_SESSION['username'];   
      //echo "customer session successful using".$username;            
  }
  
/* if($isset($_SESSION['Balance'])){
  }
  else{
      $Balance=$_SESSION['Balance'];               
  }   */  
  
  if(!isset($_SESSION['admin_username'])){
      
  }
  else{
            $admin_username=$_SESSION['admin_username'];
            //$ad_username=("SELECT * from admin where admin_name ='$admin_username'");
            //$admin = mysql_fetch_array($ad_username);
            //$admin_id =$admin[0];
            //$_SESSION['adminid']=$admin_id;
  }
?>      
