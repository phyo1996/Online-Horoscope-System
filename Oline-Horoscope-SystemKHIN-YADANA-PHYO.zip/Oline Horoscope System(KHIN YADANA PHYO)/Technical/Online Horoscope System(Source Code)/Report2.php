<?php
      session_start();
if($_SESSION['admin_username'])
{
                    // starting session
       require_once('session.php');           // call sesssion page

?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>the total number of the  horoscope time and total charges monthly</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
<meta charset="utf-8">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\themes\base\jquery-ui.css">
  <script src="\\jquery-ui-1.10.4\jquery-1.10.2.js"></script>
  <script src="\\jquery-ui-1.10.4\ui/jquery-ui.js"></script>
  <link rel="stylesheet" href="\\jquery-ui-1.10.4\demos\demos.css">
  <script>
  $(function() {                                                     
    $( "#datepicker" ).datepicker({dateFormat: 'yy-mm-dd'});
  });
  </script>
  <script>
  $(function() {
    $( "#datepickerend" ).datepicker({dateFormat: 'yy-mm-dd'});
  });
  </script>
    </head>                                                                        
      <body style="text-align:center">
<form name="BS" id="BS" action="" method="post"> 
                <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->
        <!--Menu-->
        <?php
            include('Menu.php');
        ?>
        
                <!--Body-->
        <div class="body">
                <table align="center" class="param">
                <tr>
                    <td>Start Date:</td>
                    <td>
                      
                        <input name="start_date" type="text" id="datepicker" >
              
                    </td>                           
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>End Date:</td>
                    <td>
                      
                        <input name="end_date" type="text" id="datepickerend" >
              
                    </td>                           
                    <td><input type="submit" name="view" value="View"/></td>
                    <td></td>
                </tr>
            </table>        
            <?php
            
 if ($_POST['view'] == "View")         //Clicking view button
 {       
     if(isset($_POST['start_date']))        //Getting data from combo
        $s_date = $_POST['start_date'];
         else
        $s_date="";
        if(isset($_POST['end_date']))
         $e_date=$_POST['end_date'];
        else
        $e_date="";

       $conn = new PDO("mysql:host=localhost;dbname=online_horoscope_system",'root' );      //Getting connection and calling Stored Procedure   
        $sql="Call Rpt_asking_frequency('$s_date','$e_date')";
        $q = $conn->query($sql);
        $q->setFetchMode(PDO::FETCH_ASSOC); 
  //  $GET_Item=mysql_query($sql) or die(mysql_error());
               
                                                               
    echo '<table align="center" class="rpt">';
        echo '<tr>';
                echo '<td><img style="width:100px; height:100px;" src="Image/logo.gif"/></td>';
                echo '<td colspan="3"><b><u> The frequency Of Asking Time Report</u></b></td>';   
       echo '</tr>';

        echo '<tr>';             //table header Name 
        echo '<th class="rpt"> Member ID </th>'  
            .'<th class="rpt"> Member Name </th>'
            .'<th class="rpt"> horoscope_description </th>'  
             .'<th class="rpt"> Time Asking </th>'
             .'<th class="rpt"> Total Charges </th>';        
        echo '</tr>';

  
          
      while($r=$q->fetch())   //Calling data by looping   
  {        
        echo  '<tr>'; 
      echo '<td class="rpt">'.$r['customer_id'].'</td>' 
          .'<td class="rpt">'.$r['customer_name'].'</td>'
          .'<td class="rpt">'.$r['horoscope_description'].'</td>'  
          .'<td class="rpt">'.$r['Time_Asking'].'</td>'
          .'<td class="rpt">'.$r['Total_Charges'].'</td>';  
      echo '</tr>';

  } 
 
   
       echo '</table>';                         
                                                    
 }
               ?>
               </div>
                   <!--    <table align="center" class="param">
                <tr>
                    <td>Choose Month & Year:</td>
                    <td>
                        <select name="month" id="month" style="width:190px">
                        <option value="Choose Month">Janurary</option> 
                        </select>
                        <select>
                        <option value="Choose Month">2013</option> 
                        </select>
                    </td>                           
                    <td><input type="button" name="view" value="View"/></td>
                    <td></td>
                </tr>
            </table>  
                      
            <table align="center" class="rpt">              
                <tr>
                    <td><img style="width:100px; height:100px;" src="Image/logo.gif"/></td>
                    <td colspan="4"><b><u>The frequency Of Asking Time Report for the Month of December</u></b></td>   
                </tr>
                <tr style="text-align:right;">
                    <td colspan="6">Report Date: 31/december/2013</td>                       
                </tr> 
                <tr>
                    <td class="rpt">Member ID</td>
                    <td class="rpt">Member Name</td>
                    <td class="rpt">Gender</td>
                    <td class="rpt">Horoscope</td>                     
                    <td class="rpt">Times Asked</td>
                    <td class="rpt">Total Charges</td>
                </tr>                                    
                <tr>
                    <td class="rptData">M0001</td>
                    <td class="rptData">Mary</td>                     
                    <td class="rptData">Female</td>
                    <td class="rptData">Aries</td>
                    <td class="rptData">35</td>                      
                    <td class="rptData">1750</td>
                </tr>
                <tr>
                    <td class="rptData">M0006</td>
                    <td class="rptData">Peter</td>                     
                    <td class="rptData">Male</td>
                    <td class="rptData">Leo</td>
                    <td class="rptData">15</td>                      
                    <td class="rptData">1500</td>
                </tr>
                <tr>
                    <td class="rptData">M0007</td>
                    <td class="rptData">Mary</td>                     
                    <td class="rptData">Female</td>
                    <td class="rptData">Gemini</td>
                    <td class="rptData">8</td>                      
                    <td class="rptData">800</td>
                </tr>
                <tr>
                    <td class="rptData">M0059</td>
                    <td class="rptData">Richard</td>                     
                    <td class="rptData">Male</td>
                    <td class="rptData">Virgo</td>
                    <td class="rptData">5</td>                      
                    <td class="rptData">5000</td>
                </tr>
               
                <tr>
                    <td colspan="4" class="rpt">Total Number of Asking Times :</td>
                    <td colspan="2" class="rpt">9050</td>
                </tr>                 
                <tr>
                    <td></td>
                    <td></td>
                </tr>                                   
            </table>    
         </div>  -->                                                                    
        <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
             
            <a class="menu" href="Help.php">Help</a>  
            <br/>
        � KYDNP
        </div>
     </form>
    </body>
</html>
<?php
}
else{
    echo "<script>window.location='staff_login.php';</script>";
}
    
    ?>