<?php
                 session_start();   
?>

<html>
    <head>
        <!--Enter Web Page Name-->
        <title>Customer Registration Page</title>
        <!--Enter CSS file path in href ie.folder/file.css-->
        <link rel="stylesheet" type="text/css" href="CSS/Test.css" />  
        
    </head>

    <body style="text-align:center">

                <table style="width:950px; margin-left:200px" class="header" bgcolor="#FDB73D"  > 
        <tr><td>
            <? include('Welcome.php')?>
        </td></tr>
        </table>
    
        <!--Header Image-->
        <div class="header">
        <img src="Image/banner.jpg" />
        </div>
        
        <!--Menu-->

        <?php
            include('Menu.php');
        ?>
        
        <!--Body-->
        <div class="body">

             <p align="justify">I am account ambassador,Phyo Phyo.This website had been started since 2001. This page include (7) pages. <br />
                   (1)Home page </br>
                   (2)Log in page  </br>  
                   (3)Registration page   </br>  
                   (4)Billing page      </br>  
                   (5)Report page     </br>  
                   (6)Asking page     </br>  
                   (7)Help page</p>     
                   <p>Our Horoscope system started in 1998 but that is local business. According to 2001 job survey, the people have been working today more and more ,even the girls,women and housewife.No time they give the time asking horoscope.So that, I become having the idea to do this website.So that, I try to configure this website for one year.In 2003, our website members and audiences extremely improve in 2005.Now 2014, Your website reputation become progress and progress. </p>

                       <table align="center" bgcolor="pink">
                       <p> Do U have a failure or Do u have a dicussion??? </p>
                       <td align="center"> Content us</td>
                       <td align="center"><a href="home.php">KYND@gmail.com</a></td>
                       </table>
         </div>                                                                      
 <!--Footer-->
        <div class="footer">   
            <a class="menu" href="Aboutus.php">About Us</a> |
          
            <a class="menu" href="HelpCentre.php">Help</a>  
            <br/>
<div>
<a href="#"><img src="Image/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="Image/flickr.png" alt="Flickr" /></a>
        <a href="#"><img src="Image/twitter.png" alt="Twitter" /></a>
</div> 

    </body>
</html>